package com.centralhex.jarvis.core

import android.util.Base64
import com.centralhex.jarvis.data.JarvisSettings
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.double
import kotlinx.serialization.json.int
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * Les « connecteurs » : tout ce que JARVIS sait faire en appelant un service par le réseau.
 * Inspirés des intégrations du projet jarvis-assistant-vocal (MIT), recodés pour Android.
 * Rien n'est obligatoire : chaque connecteur ne marche que si tu l'as renseigné dans Réglages ▸ Connexions.
 */
object Connectors {

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()
    private val JSON_TYPE = "application/json".toMediaType()

    private fun httpGet(url: String): String =
        http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty() }

    private fun httpSend(method: String, url: String, body: String): String =
        http.newCall(Request.Builder().url(url).method(method, body.toRequestBody(JSON_TYPE)).build())
            .execute().use { it.body?.string().orEmpty() }

    // ───────────── Météo (Open-Meteo, gratuit, sans clé ni position) ─────────────

    private fun weatherWord(code: Int) = when (code) {
        0 -> "ciel dégagé"
        1 -> "plutôt dégagé"
        2 -> "partiellement nuageux"
        3 -> "ciel couvert"
        45, 48 -> "brouillard"
        in 51..57 -> "bruine"
        in 61..67 -> "pluie"
        in 71..77 -> "neige"
        in 80..82 -> "averses"
        85, 86 -> "averses de neige"
        in 95..99 -> "orage"
        else -> "temps variable"
    }

    suspend fun weather(city: String, tomorrow: Boolean): String = withContext(Dispatchers.IO) {
        val geo = Json.parseToJsonElement(
            httpGet("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(city, "UTF-8") + "&count=1&language=fr&format=json")
        ).jsonObject
        val place = geo["results"]?.jsonArray?.firstOrNull()?.jsonObject
            ?: return@withContext "Je ne trouve pas la ville « $city »."
        val lat = place["latitude"]!!.jsonPrimitive.double
        val lon = place["longitude"]!!.jsonPrimitive.double
        val name = place["name"]?.jsonPrimitive?.contentOrNull ?: city

        val f = Json.parseToJsonElement(
            httpGet(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                    "&timezone=auto&forecast_days=2"
            )
        ).jsonObject
        val daily = f["daily"]!!.jsonObject
        val i = if (tomorrow) 1 else 0
        fun day(key: String) = daily[key]!!.jsonArray[i].jsonPrimitive
        val code = day("weather_code").int
        val max = Math.round(day("temperature_2m_max").double).toInt()
        val min = Math.round(day("temperature_2m_min").double).toInt()
        val rain = day("precipitation_probability_max").intOrNull
        val rainText = if (rain != null) ", $rain % de risque de pluie" else ""

        if (tomorrow) {
            "Demain à $name : ${weatherWord(code)}, entre $min et $max degrés$rainText."
        } else {
            val cur = f["current"]!!.jsonObject
            val now = Math.round(cur["temperature_2m"]!!.jsonPrimitive.double).toInt()
            val nowCode = cur["weather_code"]!!.jsonPrimitive.int
            "À $name : $now degrés, ${weatherWord(nowCode)}. Aujourd'hui entre $min et $max degrés$rainText."
        }
    }

    // ───────────── Agenda (lien iCal / « adresse secrète » de Google Agenda) ─────────────

    suspend fun agenda(url: String, dayOffset: Int): String = withContext(Dispatchers.IO) {
        val raw = httpGet(url.trim().replace("webcal://", "https://"))
        val text = raw.replace(Regex("\r?\n[ \t]"), "")                         // dépliage des lignes iCal
        val dayFmt = SimpleDateFormat("yyyyMMdd", Locale.US)
        val target = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, dayOffset) }
        val day = dayFmt.format(target.time)
        val utc = SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val local = SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US)
        val hourFmt = SimpleDateFormat("HH'h'mm", Locale.FRENCH)

        val events = mutableListOf<Triple<Long, String, String>>()
        var repeating = false
        for (block in text.split("BEGIN:VEVENT").drop(1)) {
            val body = block.substringBefore("END:VEVENT")
            val summary = Regex("(?m)^SUMMARY[^:\n]*:(.*)$").find(body)?.groupValues?.get(1)?.trim()
                ?.replace("\\,", ",")?.replace("\\n", " ") ?: continue
            val start = Regex("(?m)^DTSTART[^:\n]*:(\\S+)").find(body)?.groupValues?.get(1) ?: continue
            if (body.contains("RRULE")) repeating = true
            if (start.length == 8) {
                if (start == day) events.add(Triple(0L, "toute la journée", summary))
                continue
            }
            val date: Date = try { if (start.endsWith("Z")) utc.parse(start)!! else local.parse(start)!! } catch (e: Exception) { continue }
            if (dayFmt.format(date) == day) events.add(Triple(date.time, hourFmt.format(date), summary))
        }
        val word = if (dayOffset == 0) "Aujourd'hui" else "Demain"
        val note = if (repeating) " (les événements qui se répètent ne sont pas encore pris en charge)" else ""
        if (events.isEmpty()) "Rien de prévu ${word.lowercase()}." + note
        else "$word tu as ${events.size} événement${if (events.size > 1) "s" else ""} : " +
            events.sortedBy { it.first }.joinToString(", ") { "${it.second} ${it.third}" } + "." + note
    }

    // ───────────── Philips Hue (pont sur le réseau Wi-Fi local) ─────────────

    private val hueColors = mapOf(
        "rouge" to 0, "orange" to 5000, "jaune" to 12750, "vert" to 25500, "cyan" to 36000,
        "bleu" to 46920, "violet" to 50000, "rose" to 56100, "magenta" to 56100
    )

    /** Appuie sur le bouton du pont Hue puis appelle ça : renvoie la clé d'accès. */
    suspend fun huePair(ip: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val resp = httpSend("POST", "http://${ip.trim()}/api", """{"devicetype":"jarvis#telephone"}""")
            val first = Json.parseToJsonElement(resp).jsonArray.first().jsonObject
            val key = first["success"]?.jsonObject?.get("username")?.jsonPrimitive?.contentOrNull
            if (key != null) Result.success(key)
            else Result.failure(Exception("Appuie d'abord sur le gros bouton du pont Hue, puis réessaie dans les 30 secondes."))
        } catch (e: Exception) {
            Result.failure(Exception("Je n'atteins pas le pont Hue (${e.message}). Vérifie l'adresse IP et que le téléphone est sur le même Wi-Fi."))
        }
    }

    suspend fun hue(s: JarvisSettings, room: String?, on: Boolean, brightnessPct: Int?, color: String?): String = withContext(Dispatchers.IO) {
        if (s.hueIp.isBlank() || s.hueKey.isBlank()) return@withContext "Philips Hue n'est pas configuré. Va dans Réglages ▸ Connexions."
        val base = "http://${s.hueIp.trim()}/api/${s.hueKey.trim()}"
        var groupId = "0"
        var label = "toutes les lumières"
        if (!room.isNullOrBlank()) {
            val groups = Json.parseToJsonElement(httpGet("$base/groups")).jsonObject
            fun nameOf(o: JsonObject) = o["name"]?.jsonPrimitive?.contentOrNull ?: ""
            val best = groups.entries.maxByOrNull { Fuzzy.similarity(room, nameOf(it.value.jsonObject)) }
            if (best == null || Fuzzy.similarity(room, nameOf(best.value.jsonObject)) < 0.6) return@withContext "Je ne trouve pas la pièce « $room » dans Hue."
            groupId = best.key
            label = "les lumières de ${nameOf(best.value.jsonObject)}"
        }
        val body = buildJsonObject {
            put("on", on)
            if (on) {
                brightnessPct?.let { put("bri", it.coerceIn(1, 100) * 254 / 100) }
                color?.let { c ->
                    if (c == "blanc") put("ct", 300)
                    else hueColors[c]?.let { h -> put("hue", h); put("sat", 254) }
                }
            }
        }
        val resp = httpSend("PUT", "$base/groups/$groupId/action", body.toString())
        if (resp.contains("\"error\"")) "Hue a refusé la commande." else if (on) "J'allume $label." else "J'éteins $label."
    }

    /** Active une ambiance (« scène ») Hue par son nom ; sans nom, liste les ambiances disponibles. */
    suspend fun hueScene(s: JarvisSettings, name: String): String = withContext(Dispatchers.IO) {
        if (s.hueIp.isBlank() || s.hueKey.isBlank()) return@withContext "Philips Hue n'est pas configuré. Va dans Réglages, Connexions."
        val base = "http://${s.hueIp.trim()}/api/${s.hueKey.trim()}"
        val scenes = Json.parseToJsonElement(httpGet("$base/scenes")).jsonObject
        fun nameOf(o: JsonObject) = o["name"]?.jsonPrimitive?.contentOrNull ?: ""
        if (name.isBlank()) {
            val names = scenes.values.map { nameOf(it.jsonObject) }.filter { it.isNotBlank() }.distinct().take(8)
            return@withContext if (names.isEmpty()) "Je ne trouve aucune ambiance dans Hue." else "Tes ambiances : " + names.joinToString(", ") + "."
        }
        val best = scenes.entries.maxByOrNull { Fuzzy.similarity(name, nameOf(it.value.jsonObject)) }
        if (best == null || Fuzzy.similarity(name, nameOf(best.value.jsonObject)) < 0.55) return@withContext "Je ne trouve pas l'ambiance « $name »."
        val group = best.value.jsonObject["group"]?.jsonPrimitive?.contentOrNull ?: "0"
        val body = buildJsonObject { put("scene", best.key) }.toString()
        val resp = httpSend("PUT", "$base/groups/$group/action", body)
        if (resp.contains("\"error\"")) "Hue a refusé l'ambiance." else "Ambiance ${nameOf(best.value.jsonObject)} activée."
    }

    // ───────────── Discord (webhook de salon) ─────────────

    suspend fun discord(webhook: String, message: String): String = withContext(Dispatchers.IO) {
        if (webhook.isBlank()) return@withContext "Discord n'est pas configuré. Colle l'adresse du webhook dans Réglages ▸ Connexions."
        val body = buildJsonObject { put("content", message.take(1900)); put("username", "JARVIS") }.toString()
        http.newCall(Request.Builder().url(webhook.trim()).post(body.toRequestBody(JSON_TYPE)).build())
            .execute().use { if (it.isSuccessful) "Message envoyé sur Discord." else "Discord a refusé le message (${it.code})." }
    }

    // ───────────── OBS (obs-websocket v5, sur le même réseau) ─────────────

    private fun sha256b64(input: String): String =
        Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(input.toByteArray()), Base64.NO_WRAP)

    /** Envoie une requête à OBS (StartStream, StopStream, StartRecord, StopRecord, SetCurrentProgramScene…). Renvoie « ok » ou l'erreur. */
    suspend fun obs(host: String, password: String, request: String, data: JsonObject? = null): String = withContext(Dispatchers.IO) {
        val result = CompletableDeferred<String>()
        val ws = http.newWebSocket(Request.Builder().url("ws://${host.trim()}").build(), object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val o = Json.parseToJsonElement(text).jsonObject
                    val op = o["op"]!!.jsonPrimitive.int
                    val d = o["d"]!!.jsonObject
                    when (op) {
                        0 -> {   // Hello : on s'identifie (avec le mot de passe s'il y en a un)
                            val auth = d["authentication"]?.jsonObject
                            val identify = buildJsonObject {
                                put("op", 1)
                                put("d", buildJsonObject {
                                    put("rpcVersion", 1)
                                    if (auth != null) {
                                        val salt = auth["salt"]!!.jsonPrimitive.content
                                        val challenge = auth["challenge"]!!.jsonPrimitive.content
                                        put("authentication", sha256b64(sha256b64(password + salt) + challenge))
                                    }
                                })
                            }
                            webSocket.send(identify.toString())
                        }
                        2 -> {   // Identifié : on envoie la demande
                            val req = buildJsonObject {
                                put("op", 6)
                                put("d", buildJsonObject {
                                    put("requestType", request)
                                    put("requestId", "1")
                                    if (data != null) put("requestData", data)
                                })
                            }
                            webSocket.send(req.toString())
                        }
                        7 -> {   // Réponse
                            val st = d["requestStatus"]?.jsonObject
                            if (st?.get("result")?.jsonPrimitive?.booleanOrNull == true) result.complete("ok")
                            else result.complete(st?.get("comment")?.jsonPrimitive?.contentOrNull ?: "refusé")
                            webSocket.close(1000, null)
                        }
                    }
                } catch (e: Exception) { result.complete("réponse illisible") }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                result.complete("je n'atteins pas OBS (${t.message})")
            }
        })
        val out = withTimeoutOrNull(8000) { result.await() } ?: "pas de réponse d'OBS"
        ws.cancel()
        out
    }

    // ───────────── Réveiller le PC (Wake-on-LAN) ─────────────

    suspend fun wakePc(mac: String): String = withContext(Dispatchers.IO) {
        val hex = mac.replace(Regex("[^0-9A-Fa-f]"), "")
        if (hex.length != 12) return@withContext "L'adresse MAC du PC n'est pas valide. Vérifie-la dans Réglages ▸ Connexions."
        val macBytes = ByteArray(6) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val packet = ByteArray(6) { 0xFF.toByte() } + ByteArray(16 * 6) { macBytes[it % 6] }
        DatagramSocket().use { s ->
            s.broadcast = true
            s.send(DatagramPacket(packet, packet.size, InetAddress.getByName("255.255.255.255"), 9))
        }
        "J'envoie le signal de réveil à ton PC."
    }
}
