package com.centralhex.jarvis.core

import android.app.KeyguardManager
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Tout ce que JARVIS peut faire sur le téléphone. Chaque action vérifie la
 * permission avant d'agir ; si elle manque, on bascule sur l'action "manuelle"
 * (ouvrir l'appli Téléphone/Messages déjà pré-remplie) plutôt que d'échouer.
 */
class DeviceActions(private val context: Context) {

    private fun has(perm: String) =
        ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED

    /** Liste des applications que l'utilisateur peut ouvrir (nom affiché -> nom de paquet). */
    fun listInstalledApps(): Map<String, String> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = context.packageManager
        return pm.queryIntentActivities(intent, 0).associate { info ->
            info.loadLabel(pm).toString() to info.activityInfo.packageName
        }
    }

    /** Cherche l'appli dont le nom ressemble le plus à [query] et l'ouvre. */
    fun openApp(query: String): String {
        val q = normalize(query).replace("'", " ").replace("’", " ")
            .replace(Regex("^(?:(?:l application|l appli|l app|application|appli|app|l|la|le|les|mon|ma|mes|du)\\s+)+"), "")
            .trim()

        systemAppIntent(q)?.let { (label, intent) ->
            if (tryStartSilently(intent)) return launchResult(intent, label, "J'ouvre $label.")
        }

        val apps = listInstalledApps()
        val match = apps.entries.firstOrNull { normalize(it.key) == q }
            ?: apps.entries.firstOrNull { normalize(it.key).contains(q) || q.contains(normalize(it.key)) }
            ?: bestAppBySound(q, apps, 0.72)
            ?: return notFoundMessage(query, q, apps)
        val launchIntent = context.packageManager.getLaunchIntentForPackage(match.value)
            ?: return "Je n'arrive pas à ouvrir ${match.key}."
        return launchResult(launchIntent, match.key, "J'ouvre ${match.key}.")
    }

    /** L'appli dont le nom SONNE comme [q] (« face book » → Facebook), si la ressemblance est assez forte. */
    private fun bestAppBySound(q: String, apps: Map<String, String>, min: Double): Map.Entry<String, String>? {
        val best = apps.entries.maxByOrNull { Fuzzy.similarity(q, it.key) } ?: return null
        return if (Fuzzy.similarity(q, best.key) >= min) best else null
    }

    private fun notFoundMessage(query: String, q: String, apps: Map<String, String>): String {
        val close = apps.keys.sortedByDescending { Fuzzy.similarity(q, it) }.take(2)
            .filter { Fuzzy.similarity(q, it) >= 0.5 }
        return if (close.isEmpty()) "Je ne trouve pas d'application qui ressemble à « $query »."
        else "Je ne trouve pas « $query ». Tu voulais dire " + close.joinToString(" ou ") + " ?"
    }

    /** Une phrase courte qui ne contient que le nom d'une appli (« facebook ») : on l'ouvre. */
    fun openAppIfMatch(phrase: String): String? {
        val tokens = Fuzzy.clean(phrase).split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return null
        val apps = listInstalledApps()
        for (len in minOf(3, tokens.size) downTo 1) {
            for (i in 0..tokens.size - len) {
                val candidate = tokens.subList(i, i + len).joinToString(" ")
                val m = bestAppBySound(candidate, apps, 0.82) ?: continue
                val intent = context.packageManager.getLaunchIntentForPackage(m.value) ?: continue
                return launchResult(intent, m.key, "J'ouvre ${m.key}.")
            }
        }
        return null
    }

    /** « C'est quoi cette musique ? » : ouvre Shazam, ou la recherche musicale de Google à défaut. */
    fun identifyMusic(): String {
        context.packageManager.getLaunchIntentForPackage("com.shazam.android")?.let {
            return launchResult(it, "Shazam", "J'ouvre Shazam : touche le bouton pour identifier la musique.")
        }
        val g = Intent("com.google.android.googlequicksearchbox.MUSIC_SEARCH")
        if (tryStartSilently(g)) return launchResult(g, "la recherche musicale de Google", "J'écoute la musique avec Google.")
        return "Installe Shazam, et je l'ouvrirai pour identifier la musique."
    }

    // ───────────── Agenda du téléphone ─────────────
    fun hasCalendarPermission(): Boolean = CalendarTools.hasPermission(context)
    fun calendarSummary(dayOffset: Int, days: Int): String = CalendarTools.summary(context, dayOffset, days)
    fun calendarCreate(title: String, begin: Long): String = CalendarTools.create(context, title, begin)
    fun calendarFind(query: String): CalendarTools.Ev? = CalendarTools.findUpcoming(context, query)
    fun calendarDelete(e: CalendarTools.Ev): String = CalendarTools.delete(context, e)

    /** « Stats du téléphone » : mémoire, stockage, batterie, température, durée depuis le démarrage. */
    fun stats(): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val gb = 1024.0 * 1024.0 * 1024.0
        val st = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val bat = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (bat?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10
        val b = batteryInfo()
        val up = android.os.SystemClock.elapsedRealtime() / 60_000
        return "Mémoire : %.1f Go libres sur %.1f. Stockage : %.0f Go libres sur %.0f. Batterie à %d %%%s, %d degrés. Allumé depuis %d h %d.".format(
            Locale.FRENCH, mi.availMem / gb, mi.totalMem / gb, st.availableBytes / gb, st.totalBytes / gb,
            b.percent, if (b.charging) " en charge" else "", temp, up / 60, up % 60
        )
    }

    /** Place libre sur le téléphone. */
    fun storageInfo(): String {
        val st = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val gb = 1024.0 * 1024.0 * 1024.0
        val free = st.availableBytes / gb
        val total = st.totalBytes / gb
        return "Il reste %.1f Go libres sur %.0f Go.".format(Locale.FRENCH, free, total)
    }

    /** Recherche sur le web (appli Google ou navigateur). */
    fun webSearch(query: String): String {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, query)
        return launchResult(i, "la recherche", "Je cherche « $query » sur le web.")
    }

    /** Vérifie qu'une appli sait gérer l'intention, sans la lancer. */
    private fun tryStartSilently(intent: Intent): Boolean =
        try { intent.resolveActivity(context.packageManager) != null } catch (e: Exception) { false }

    /** Cherche un numéro dans les contacts à partir d'un nom. */
    /** "ma mère" doit aussi trouver "Maman", "Mama"… */
    private fun contactAliases(name: String): List<String> {
        val full = normalize(name)
        val bare = full.replace(Regex("^(ma|mon|mes|le|la|l)\\s+"), "").trim()
        val extra = when (bare) {
            "mere", "maman", "mama", "mom", "ma maman" -> listOf("maman", "mama", "mere", "mom")
            "pere", "papa", "dad" -> listOf("papa", "pere", "dad")
            "soeur", "sis" -> listOf("soeur", "sis")
            "frere", "bro" -> listOf("frere", "bro")
            else -> emptyList()
        }
        return (listOf(full, bare) + extra).filter { it.isNotBlank() }.distinct()
    }

    fun findContactNumber(name: String): String? {
        if (!has(android.Manifest.permission.READ_CONTACTS)) return null
        val contacts = mutableListOf<Pair<String, String>>()
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                contacts += normalize(n) to num
            }
        } ?: return null
        for (alias in contactAliases(name)) {
            contacts.firstOrNull { it.first == alias }?.let { return it.second }
            contacts.firstOrNull { it.first.contains(alias) }?.let { return it.second }
        }
        // dernier recours : le contact dont le NOM RESSEMBLE le plus (le micro écorche souvent les prénoms)
        val best = contacts.maxByOrNull { Fuzzy.similarity(name, it.first) }
        if (best != null && Fuzzy.similarity(name, best.first) >= 0.78) return best.second
        return null
    }

    /** Appelle un numéro (ou un nom de contact). */
    @android.annotation.SuppressLint("MissingPermission")
    fun call(target: String): String {
        val number = if (target.any(Char::isDigit) && target.count(Char::isDigit) >= 6) target
        else findContactNumber(target) ?: return "Je n'ai pas trouvé « $target » dans tes contacts."

        if (has(android.Manifest.permission.CALL_PHONE)) {
            // TelecomManager : Android autorise ça même quand JARVIS est en arrière-plan (contrairement à startActivity).
            try {
                val tm = context.getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
                tm.placeCall(Uri.fromParts("tel", number, null), android.os.Bundle())
                return "J'appelle $target."
            } catch (e: Exception) { /* on essaie la méthode classique ci-dessous */ }
            if (tryStart(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))) return "J'appelle $target."
        }
        tryStart(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        return "Je n'ai pas la permission d'appeler directement, j'ouvre le composeur pour $number."
    }

    @Suppress("DEPRECATION")
    fun sendSms(target: String, body: String): String {
        val number = if (target.any(Char::isDigit) && target.count(Char::isDigit) >= 6) target
        else findContactNumber(target) ?: return "Je n'ai pas trouvé « $target » dans tes contacts."

        if (body.isBlank()) {
            return if (tryStart(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)))
                "J'ouvre Messages pour $target." else "Je n'ai pas trouvé d'application de messages."
        }

        if (has(android.Manifest.permission.SEND_SMS)) {
            return try {
                val sms: SmsManager = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S)
                    context.getSystemService(SmsManager::class.java)
                else SmsManager.getDefault()
                val parts = sms.divideMessage(body)
                if (parts.size > 1) sms.sendMultipartTextMessage(number, null, parts, null, null)
                else sms.sendTextMessage(number, null, body, null, null)
                "SMS envoyé à $target."
            } catch (e: Exception) {
                openSmsCompose(number, body)
                "L'envoi direct a échoué (${e.message}). J'ai ouvert Messages : appuie sur envoyer."
            }
        }

        // Permission SMS absente (souvent bloquée par Android pour les applis installées hors Play Store)
        openSmsCompose(number, body)
        return "Android bloque l'envoi direct de SMS pour JARVIS, j'ai ouvert Messages : appuie sur envoyer. " +
            "Pour l'activer : Réglages ▸ Ouvrir les paramètres de l'appli ▸ menu ⋮ ▸ Autoriser les paramètres restreints, puis Autorisations ▸ SMS."
    }

    private fun openSmsCompose(number: String, body: String) {
        tryStart(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /**
     * Lance une activité. Quand JARVIS est en arrière-plan, Android bloque souvent l'ouverture (sans erreur) :
     * on ajoute alors une notification à toucher, pour que l'action ne soit jamais perdue.
     */
    private fun tryStart(intent: Intent, label: String = "l'application"): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val launcher: Context = JarvisAccessibilityService.instance ?: context   // le service d'accessibilité est mieux placé pour lancer une activité
        // Appli fermée : on prépare toujours une notification « touche pour ouvrir » en secours
        // (bruyante si Android risque de bloquer l'ouverture, discrète si la boule flottante la rend possible).
        if (!WakeWordService.isAppVisible()) postTapNotification(intent, label, loud = !WakeWordService.isOrbShown())
        return try { launcher.startActivity(intent); true } catch (e: Exception) { false }
    }

    /** Ouvre Paramètres ▸ Accessibilité, pour activer le contrôle vocal du téléphone. */
    fun openAccessibilitySettings(): Boolean = try {
        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    /** Vrai si l'appli est visible, ou si la boule flottante est affichée (Android autorise alors l'ouverture). */
    private fun canLaunchDirectly(): Boolean = WakeWordService.isAppVisible() || WakeWordService.isOrbShown()

    private fun postTapNotification(intent: Intent, label: String, loud: Boolean) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel("jarvis_actions", "Actions de JARVIS", android.app.NotificationManager.IMPORTANCE_HIGH)
                )
                nm.createNotificationChannel(
                    android.app.NotificationChannel("jarvis_actions_quiet", "Actions de JARVIS (discret)", android.app.NotificationManager.IMPORTANCE_LOW)
                )
            }
            val pi = android.app.PendingIntent.getActivity(
                context, label.hashCode(), intent,
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = androidx.core.app.NotificationCompat.Builder(context, if (loud) "jarvis_actions" else "jarvis_actions_quiet")
                .setSmallIcon(android.R.drawable.presence_audio_online)
                .setContentTitle("JARVIS")
                .setContentText("Touche pour ouvrir $label")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(if (loud) androidx.core.app.NotificationCompat.PRIORITY_HIGH else androidx.core.app.NotificationCompat.PRIORITY_LOW)
                .setTimeoutAfter(20_000)
                .build()
            nm.notify(label.hashCode(), n)
        } catch (e: Exception) { /* pas grave */ }
    }

    private fun launchResult(intent: Intent, label: String, okMsg: String): String {
        val direct = canLaunchDirectly()
        val started = tryStart(intent, label)
        return when {
            !started -> "Je n'arrive pas à ouvrir $label."
            direct -> okMsg
            else -> "Touche la notification pour ouvrir $label. Android bloque l'ouverture automatique : active la boule flottante pour que ce soit direct."
        }
    }

    /** « répertoire », « galerie », « paramètres »… : applis système, reconnues par leur rôle plutôt que par leur nom. */
    private fun systemAppIntent(q: String): Pair<String, Intent>? {
        fun sel(cat: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)
        return when (q) {
            "repertoire", "contacts", "contact", "carnet d adresses", "mes contacts" -> "tes contacts" to sel(Intent.CATEGORY_APP_CONTACTS)
            "galerie", "photos", "mes photos", "images" -> "ta galerie" to sel(Intent.CATEGORY_APP_GALLERY)
            "navigateur", "internet", "navigateur web" -> "le navigateur" to sel(Intent.CATEGORY_APP_BROWSER)
            "calculatrice", "calculette" -> "la calculatrice" to sel(Intent.CATEGORY_APP_CALCULATOR)
            "calendrier", "agenda" -> "ton calendrier" to sel(Intent.CATEGORY_APP_CALENDAR)
            "email", "mail", "mails", "courrier", "e mail" -> "tes e-mails" to sel(Intent.CATEGORY_APP_EMAIL)
            "carte", "cartes", "maps" -> "la carte" to sel(Intent.CATEGORY_APP_MAPS)
            "messages", "sms", "messagerie" -> "tes messages" to sel(Intent.CATEGORY_APP_MESSAGING)
            "musique" -> "la musique" to sel(Intent.CATEGORY_APP_MUSIC)
            "parametres", "parametre", "reglages", "reglage" -> "les paramètres" to Intent(Settings.ACTION_SETTINGS)
            "telephone", "appels", "clavier", "composeur" -> "le téléphone" to Intent(Intent.ACTION_DIAL)
            else -> null
        }
    }

    /** Demande à Android de ne pas endormir JARVIS : indispensable pour que « JARVIS » marche écran éteint. */
    @android.annotation.SuppressLint("BatteryLife")
    fun requestIgnoreBatteryOptimizations(): String {
        val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (pm.isIgnoringBatteryOptimizations(context.packageName)) return "C'est déjà réglé : JARVIS n'est pas limité par la batterie."
        val direct = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}"))
        if (tryStart(direct)) return "Accepte pour que JARVIS reste actif écran éteint."
        return if (tryStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) "Choisis JARVIS puis « Ne pas optimiser »." else "Je n'ai pas pu ouvrir ce réglage."
    }

    fun canDrawOverlays(): Boolean = Settings.canDrawOverlays(context)

    /**
     * « Afficher par-dessus les autres applis » : permet à JARVIS de lancer une appli, la caméra, YouTube…
     * quand tu lui parles alors qu'il est en arrière-plan (Android bloque ça sinon).
     */
    fun requestOverlayPermission(): String {
        if (Settings.canDrawOverlays(context)) return "C'est déjà autorisé."
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        return if (tryStart(i)) "Active « Autoriser l'affichage par-dessus d'autres applis » pour JARVIS." else "Je n'ai pas pu ouvrir ce réglage."
    }

    /** Ouvre l'écran "Infos de l'appli" de JARVIS (permissions, paramètres restreints, batterie). */
    fun openAppSettings(): String {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        return if (tryStart(i)) "J'ouvre les paramètres de JARVIS." else "Je n'ai pas pu ouvrir les paramètres."
    }

    // ───────────── Musique, vidéo, galerie ─────────────

    /** "joue Burna Boy" : demande à l'appli de musique (Spotify, YouTube Music…) de chercher et lancer. */
    fun playMusic(query: String): String {
        val q = query.trim()
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(android.app.SearchManager.QUERY, q)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        }
        if (tryStart(intent)) return if (q.isEmpty()) "Je lance la musique." else "Je lance « $q »."
        if (q.isEmpty()) return mediaControl("play_pause")
        return searchVideo("$q", musicFallback = true)
    }

    /** "mets une vidéo de ..." : recherche dans YouTube (appli si installée, sinon navigateur). */
    fun searchVideo(query: String, musicFallback: Boolean = false): String {
        val q = query.trim()
        if (q.isEmpty()) return openApp("YouTube")
        val yt = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
        if (tryStart(yt)) return if (musicFallback) "Pas d'appli de musique trouvée, je cherche « $q » sur YouTube." else "Je cherche « $q » sur YouTube."
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(q, "UTF-8")))
        return if (tryStart(web)) "Je cherche « $q » sur YouTube." else "Je n'ai pas pu ouvrir YouTube."
    }

    fun openGallery(): String {
        val gallery = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        if (tryStart(gallery)) return "J'ouvre ta galerie."
        val images = Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        if (tryStart(images)) return "J'ouvre tes photos."
        return openApp("Galerie")
    }

    /** Ouvre l'horloge pour régler une alarme (l'OS gère le reste, aucune permission requise). */
    fun setAlarm(hour: Int, minute: Int, label: String = "JARVIS"): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            "Alarme réglée à %02d:%02d.".format(hour, minute)
        } else "Je ne trouve pas d'application d'horloge sur ce téléphone."
    }

    // ── Tout ce qui suit fonctionne sans connexion internet ──

    fun currentTime(): String {
        val f = SimpleDateFormat("HH:mm", Locale.FRENCH)
        return "Il est ${f.format(Date())}."
    }

    fun currentDate(): String {
        val f = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH)
        return "Nous sommes le ${f.format(Date())}."
    }

    data class Battery(val percent: Int, val charging: Boolean)

    fun batteryInfo(): Battery {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return Battery(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY), bm.isCharging)
    }

    fun isWifiConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (e: Exception) { false }
    }

    fun isMobileDataConnected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) == true
        } catch (e: Exception) { false }
    }

    fun batteryStatus(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Batterie à $level %${if (charging) ", en charge" else ""}."
    }

    private var torchOn = false
    fun toggleFlashlight(on: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull() ?: return "Aucune lampe torche détectée sur cet appareil."
            cm.setTorchMode(camId, on)
            torchOn = on
            if (on) "Lampe torche allumée." else "Lampe torche éteinte."
        } catch (e: Exception) {
            "Je n'ai pas pu ${if (on) "allumer" else "éteindre"} la lampe torche."
        }
    }

    fun adjustVolume(up: Boolean): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return if (up) "Je monte le volume." else "Je baisse le volume."
    }

    /** Android empêche d'activer le Wi-Fi/Bluetooth directement depuis une appli : on ouvre le bon écran. */
    fun openSystemSettings(target: String): String {
        val action = when (target) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "J'ouvre les réglages $target."
    }

    /** Ouvre l'appareil photo. */
    fun openCamera(): String {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "J'ouvre l'appareil photo."
        } else "Aucune application appareil photo trouvée."
    }

    /** Ouvre l'appli de cartes (plan centré sur la position actuelle, gérée par l'appli elle-même). */
    fun openMap(): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent); "J'ouvre la carte."
        } else "Aucune application de cartes trouvée."
    }

    /** Lecture / pause / piste suivante / précédente — fonctionne avec le lecteur de musique déjà actif. */
    fun mediaControl(action: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (action) {
            "play_pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "Commande média inconnue."
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return when (action) {
            "play_pause" -> "C'est fait."
            "next" -> "Piste suivante."
            else -> "Piste précédente."
        }
    }

    private fun hasDndAccess(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    /** Mode sonore : silencieux / vibreur / normal. Demande une autorisation à accorder une seule fois. */
    fun setRingerMode(mode: String): String {
        if (!hasDndAccess()) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "J'ai besoin d'une autorisation pour changer le son : active JARVIS dans l'écran qui vient de s'ouvrir, puis redemande-le-moi."
        }
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.ringerMode = when (mode) {
            "silencieux" -> AudioManager.RINGER_MODE_SILENT
            "vibreur" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        return when (mode) {
            "silencieux" -> "Mode silencieux activé."
            "vibreur" -> "Mode vibreur activé."
            else -> "Son normal rétabli."
        }
    }

    /** Ne pas déranger : coupe aussi les notifications visuelles, pas seulement le son. */
    fun setDoNotDisturb(on: Boolean): String {
        if (!hasDndAccess()) {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "J'ai besoin d'une autorisation pour ça : active JARVIS dans l'écran qui vient de s'ouvrir, puis redemande-le-moi."
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return if (on) "Mode Ne pas déranger activé." else "Mode Ne pas déranger désactivé."
    }

    /** Android interdit d'activer le mode avion directement depuis une appli : on ouvre l'écran dédié. */
    fun openAirplaneModeSettings(): String {
        context.startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "J'ouvre les réglages du mode avion."
    }

    private fun adminComponent() = ComponentName(context, JarvisDeviceAdminReceiver::class.java)

    fun isDeviceAdminActive(): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent())
    }

    fun requestDeviceAdmin(): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Autorise JARVIS à verrouiller l'écran quand tu le lui demandes.")
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
        }

    /** Verrouille l'écran. Nécessite d'avoir activé "Verrouillage à distance" dans Réglages une fois. */
    fun lockScreen(): String {
        if (!isDeviceAdminActive()) return "Active d'abord « Verrouillage à distance » dans Réglages pour que je puisse verrouiller l'écran."
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        dpm.lockNow()
        return "Écran verrouillé."
    }

    fun isScreenLocked(): Boolean {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    private fun normalize(s: String) = s.lowercase()
        .replace("é", "e").replace("è", "e").replace("ê", "e")
        .replace("à", "a").replace("ù", "u").replace("ô", "o")
        .trim()
}
