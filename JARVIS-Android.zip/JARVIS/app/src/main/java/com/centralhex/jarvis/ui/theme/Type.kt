package com.centralhex.jarvis.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val mono = FontFamily.Monospace
private val base = Typography()

/** Tout le texte de l'appli est en police « terminal » (monospace). */
val JarvisTypography = Typography(
    displayLarge = base.displayLarge.copy(fontFamily = mono),
    displayMedium = base.displayMedium.copy(fontFamily = mono),
    displaySmall = base.displaySmall.copy(fontFamily = mono),
    headlineLarge = base.headlineLarge.copy(fontFamily = mono),
    headlineMedium = base.headlineMedium.copy(fontFamily = mono),
    headlineSmall = base.headlineSmall.copy(fontFamily = mono),
    titleLarge = TextStyle(fontFamily = mono, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
    titleMedium = TextStyle(fontFamily = mono, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
    titleSmall = base.titleSmall.copy(fontFamily = mono),
    bodyLarge = TextStyle(fontFamily = mono, fontSize = 15.sp, lineHeight = 21.sp),
    bodyMedium = TextStyle(fontFamily = mono, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = mono, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = base.labelLarge.copy(fontFamily = mono),
    labelMedium = TextStyle(fontFamily = mono, fontSize = 11.sp, letterSpacing = 0.5.sp),
    labelSmall = TextStyle(fontFamily = mono, fontSize = 10.sp, letterSpacing = 0.8.sp)
)
