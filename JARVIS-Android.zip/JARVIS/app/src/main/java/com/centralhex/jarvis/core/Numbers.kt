package com.centralhex.jarvis.core

/**
 * Le micro hors ligne écrit les nombres en lettres (« sept heures trente », « douze fois quinze »).
 * Ici on les remet en chiffres, pour que alarmes, minuteurs, calculs et rappels fonctionnent en parlant normalement.
 */
object Numbers {

    private val units = mapOf(
        "zero" to 0, "un" to 1, "une" to 1, "deux" to 2, "trois" to 3, "quatre" to 4, "cinq" to 5, "six" to 6, "sept" to 7,
        "huit" to 8, "neuf" to 9, "dix" to 10, "onze" to 11, "douze" to 12, "treize" to 13, "quatorze" to 14, "quinze" to 15, "seize" to 16
    )
    private val tens = mapOf("vingt" to 20, "vingts" to 20, "trente" to 30, "quarante" to 40, "cinquante" to 50, "soixante" to 60)
    private val unitWords = setOf("heure", "heures", "minute", "minutes", "seconde", "secondes", "min", "sec", "h")

    private fun isNum(w: String) = w in units || w in tens || w == "cent" || w == "cents" || w == "mille"

    private fun value(run: List<String>): Int {
        var total = 0
        var cur = 0
        var i = 0
        while (i < run.size) {
            val w = run[i]
            when {
                w == "et" -> {}
                w == "quatre" && i + 1 < run.size && (run[i + 1] == "vingt" || run[i + 1] == "vingts") -> { cur += 80; i++ }
                w in tens -> cur += tens.getValue(w)
                w in units -> cur += units.getValue(w)
                w == "cent" || w == "cents" -> cur = (if (cur == 0) 1 else cur) * 100
                w == "mille" -> { total += (if (cur == 0) 1 else cur) * 1000; cur = 0 }
            }
            i++
        }
        return total + cur
    }

    /** Texte déjà nettoyé (minuscules, sans accents) → même texte avec les nombres et les heures en chiffres. */
    fun digits(text: String): String {
        val words = text.split(" ").filter { it.isNotEmpty() }
        val out = mutableListOf<String>()
        var i = 0
        while (i < words.size) {
            if (!isNum(words[i])) { out.add(words[i]); i++; continue }
            var j = i
            val run = mutableListOf<String>()
            while (j < words.size) {
                val w = words[j]
                if (isNum(w)) run.add(w)
                else if (w == "et" && j + 1 < words.size && isNum(words[j + 1]) && run.isNotEmpty()) run.add(w)
                else break
                j++
            }
            // « un / une » seul reste un article, sauf devant une unité de temps (« une minute »)
            val lone = run.size == 1 && (run[0] == "un" || run[0] == "une")
            if (lone && !(j < words.size && words[j] in unitWords)) out.add(run[0]) else out.add(value(run).toString())
            i = j
        }
        var s = out.joinToString(" ")
        s = s.replace(Regex("\\bmidi\\b"), "12h").replace(Regex("\\bminuit\\b"), "0h")
        s = s.replace(Regex("(\\d{1,2}) heures? et demie?\\b"), "$1h30")
        s = s.replace(Regex("(\\d{1,2}) heures? et quart\\b"), "$1h15")
        s = s.replace(Regex("(\\d{1,2}) heures? moins le quart\\b")) { m -> "${(m.groupValues[1].toInt() + 23) % 24}h45" }
        s = s.replace(Regex("(\\d{1,2}) heures? (\\d{1,2})\\b"), "$1h$2")
        s = s.replace(Regex("(\\d{1,2}) heures?\\b"), "$1h")
        return s
    }
}
