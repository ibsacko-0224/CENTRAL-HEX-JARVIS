package com.centralhex.jarvis.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Le cœur de JARVIS (accueil et écran de réveil), façon Matrix : une sphère en fil de fer qui tourne,
 * des anneaux de données, un noyau qui pulse. Vert au repos, rouge quand il écoute, ambre quand il réfléchit,
 * turquoise quand il répond — et plus rapide, avec des barres de signal, quand il est actif.
 */
@Composable
fun ArcReactor(state: OrbState, diameter: Dp, modifier: Modifier = Modifier) {
    val color by animateColorAsState(orbColor(state), tween(500), label = "core")
    val speed = rememberUpdatedState(
        when (state) { OrbState.IDLE -> 1f; OrbState.THINKING -> 2.4f; OrbState.LISTENING -> 2.0f; OrbState.SPEAKING -> 2.8f }
    )
    val energy by animateFloatAsState(if (state == OrbState.IDLE) 0f else 1f, tween(600), label = "energy")
    val speaking = state == OrbState.SPEAKING

    var clock by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) clock += (now - last) / 1_000_000_000f * speed.value
                last = now
            }
        }
    }

    Canvas(modifier.size(diameter)) {
        val t = clock
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val center = Offset(cx, cy)
        val R = this.size.minDimension / 2f * 0.74f
        val pulse = 0.5f + 0.5f * sin(t * (2f + 2f * energy))
        val talk = if (speaking) 0.75f + 0.25f * sin(t * 9f) else 1f

        // halo phosphorescent
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.22f + 0.12f * pulse), Color.Transparent), center = center, radius = R * 1.55f),
            radius = R * 1.55f, center = center
        )

        // anneau extérieur + arc de balayage qui tourne
        drawCircle(color.copy(alpha = 0.35f), radius = R * 1.22f, center = center, style = Stroke(1.2f))
        rotate(t * 70f, center) {
            drawArc(
                color, startAngle = 0f, sweepAngle = 64f, useCenter = false,
                topLeft = Offset(cx - R * 1.22f, cy - R * 1.22f), size = Size(R * 2.44f, R * 2.44f),
                style = Stroke(width = 4f, cap = StrokeCap.Round)
            )
        }
        rotate(-t * 40f + 180f, center) {
            drawArc(
                color.copy(alpha = 0.6f), startAngle = 0f, sweepAngle = 28f, useCenter = false,
                topLeft = Offset(cx - R * 1.08f, cy - R * 1.08f), size = Size(R * 2.16f, R * 2.16f),
                style = Stroke(width = 3f, cap = StrokeCap.Round)
            )
        }

        // sphère en fil de fer : méridiens qui tournent, parallèles inclinés
        val spin = t * 0.7f
        for (k in 0 until 9) {
            val a = spin + k * (Math.PI.toFloat() / 9f)
            val w = R * abs(cos(a))
            if (w < 2f) continue
            drawOval(
                color.copy(alpha = 0.30f + 0.5f * abs(cos(a))), topLeft = Offset(cx - w, cy - R), size = Size(w * 2f, R * 2f),
                style = Stroke(1.5f)
            )
        }
        for (j in -3..3) {
            val y = j / 4f * R
            val r = sqrt((R * R - y * y).coerceAtLeast(0f))
            drawOval(
                color.copy(alpha = if (j == 0) 0.85f else 0.40f),
                topLeft = Offset(cx - r, cy + y - r * 0.20f), size = Size(r * 2f, r * 0.40f),
                style = Stroke(if (j == 0) 2f else 1.2f)
            )
        }

        // paquets de données qui orbitent
        for (i in 0 until 12) {
            val ang = t * (0.6f + (i % 3) * 0.25f) + i * 0.52f
            val rr = R * (1.12f + 0.04f * (i % 4))
            val half = 2.4f + (i % 3)
            val p = Offset(cx + rr * cos(ang), cy + rr * sin(ang))
            drawRect(color.copy(alpha = 0.9f), topLeft = Offset(p.x - half, p.y - half), size = Size(half * 2, half * 2))
        }

        // barres de signal quand JARVIS est actif
        if (energy > 0.05f) {
            for (i in 0 until 40) {
                val a = Math.toRadians(i * 9.0)
                val amp = (0.25f + 0.75f * abs(sin(t * 5f + i * 0.8f))) * energy * talk
                val r1 = R * 1.30f
                val r2 = r1 + R * 0.16f * amp
                drawLine(
                    color.copy(alpha = 0.85f),
                    Offset(cx + r1 * cos(a).toFloat(), cy + r1 * sin(a).toFloat()),
                    Offset(cx + r2 * cos(a).toFloat(), cy + r2 * sin(a).toFloat()),
                    strokeWidth = 3f, cap = StrokeCap.Round
                )
            }
        }

        // noyau
        val core = R * (0.16f + 0.05f * pulse)
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f), color, Color.Transparent), center = center, radius = core * 2.2f), radius = core * 2.2f, center = center)
    }
}
