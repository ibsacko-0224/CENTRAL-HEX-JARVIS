package com.centralhex.jarvis.core

import com.centralhex.jarvis.data.AutomationRule
import com.centralhex.jarvis.data.LocalStore
import com.centralhex.jarvis.data.Memory
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import com.centralhex.jarvis.data.Note

sealed class RouteResult {
    data class LocalReply(val text: String) : RouteResult()   // traité sur le téléphone, réponse immédiate
    data class AskAi(val text: String, val extra: String? = null) : RouteResult()
    /** Une action qui passe par le réseau (météo, Hue, Discord…) : le résultat arrive un peu plus tard. */
    data class Async(val block: suspend () -> String) : RouteResult()        // aucune commande reconnue : on demande à l'IA
    object StopSpeaking : RouteResult()                       // "stop" / "tais-toi" : couper la voix, sans réponse parlée
}

/**
 * Comprend les phrases simples en français avant d'appeler l'IA.
 * Ça rend JARVIS rapide et fiable pour les actions courantes, même sans
 * connexion internet ou sans clé IA configurée. Développé par CENTRAL-HEX.
 */
class CommandRouter(
    private val device: DeviceActions,
    private val reminders: ReminderScheduler,
    private val store: LocalStore
) {
    // ───────────── Nettoyage du texte ─────────────

    /** Minuscules, sans accents ni ponctuation : "Allume-moi la torche !" -> "allume moi la torche" */
    private fun base(s: String): String {
        val t = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return t.replace(Regex("[^a-z0-9: ]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    private val fillerRx = Regex(
        "\\b(?:jarvis|alors|donc|stp|svp|moi|me|dis|hey|ok|bon|bah|euh|ouais|ben|ah|eh|wesh|s il te plait|s il vous plait|" +
            "peux tu|pouvez vous|pourrais tu|tu peux|est ce que|veux tu|je veux|je voudrais|j aimerais|voudrais)\\b"
    )

    /** Pareil, mais sans les mots de politesse/remplissage : "peux tu m allumer la torche stp" -> "allumer la torche" */
    private fun clean(s: String): String = base(s).replace(fillerRx, " ").replace(Regex("\\s+"), " ").trim()

    /** Version qui garde majuscules et accents (pour les noms de contacts / d'applis), sans les "-moi" et politesses. */
    private fun soft(s: String): String {
        var t = s.trim()
        t = t.replace(Regex("(?i)\\bjarvis\\b[,\\s]*"), "")
        t = t.replace(Regex("(?i)[- ]moi\\b"), "")
        t = t.replace(Regex("(?i)^(?:(?:alors|donc|stp|svp|hey|ok|bon|peux[- ]tu|pouvez[- ]vous|tu peux|est[- ]ce que tu peux|je veux|je voudrais|j'aimerais|dis)[,\\s]+)+"), "")
        t = t.replace(Regex("(?i)[,\\s]*(?:s'il (?:te|vous) pla[iî]t|stp|svp)[\\s!.?]*$"), "")
        return t.trim()
    }

    /** Vrai si le texte contient l'un des mots/expressions, même avec une lettre de travers (le micro se trompe parfois). */
    private fun has(n: String, vararg words: String): Boolean {
        if (words.any { n.contains(it) }) return true
        val toks = n.split(" ")
        return words.any { w ->
            !w.contains(' ') && w.length >= 5 &&
                toks.any { t -> t.length >= 4 && kotlin.math.abs(t.length - w.length) <= 1 && Fuzzy.distance(t, w) <= 1 }
        }
    }

    // ───────────── Commandes avec paramètres ─────────────

    private val callRx = Regex("""^(?:appelle|appeler|telephone a|téléphone à|passe un appel a|passe un appel à|contacte)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val smsRx = Regex("""^(?:envoie|envoyer) (?:un )?(?:sms|message) (?:a|à)[ux]?\s+(.+?)\s+(?:disant|pour dire|qui dit|que)\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val sms2Rx = Regex("""^(?:dis|ecris|écris|texte|envoie un texto)\s+(?:a|à)[ux]?\s+(.+?)\s+(?:que|qu'|:)\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val smsOpenRx = Regex("""^(?:envoie|envoyer|ecris|écris) (?:un )?(?:sms|message|texto)\s+(?:a|à)[ux]?\s+(.+)$""", RegexOption.IGNORE_CASE)
    private val videoRx = Regex("""^(?:mets|met|lance|lancer|joue|jouer|regarde|regarder|cherche|chercher|montre|ouvre)\s+(?:une?\s+|la\s+|les?\s+|des\s+)?(?:videos?)\s*(?:de\s+|d\s+|du\s+|des\s+|sur\s+)?(.*)$""")
    private val videoOnYtRx = Regex("""^(?:cherche|recherche|trouve|mets|met|joue|lance|regarde)\s+(.+?)\s+sur\s+youtube$""")
    private val musicVerbRx = Regex("""^(joue|jouer|ecoute|ecouter|mets|met|lance|lancer|passe|passer|demarre|play)\s+(.*)$""")
    private val musicNounRx = Regex("""\b(?:musique|chanson|morceau|titre|album|playlist)\b""")
    private val musicLeadRx = Regex("""^(?:(?:de la|de l|du|des|la|le|les|une|un|d|l)\s+)?(?:musique|chanson|morceau|titre|album|playlist)s?\s*(?:de\s+|d\s+|du\s+|des\s+)?""")
    private val openRx = Regex(
        """^(?:ouvre|ouvrir|lance|lancer|demarre|démarre|va|vas|aller|emmene|emmène|envoie|dirige|redirige|amene|amène|accede|accède|mets|met|affiche|retourne|rentre|entre)\s+(?:(?:sur|dans|vers|a|à|au)\s+)?(?:l'application\s+|l'appli\s+|l'app\s+|application\s+|appli\s+|app\s+|l'|la\s+|le\s+|les\s+|mon\s+|ma\s+|mes\s+|du\s+)?(.+)$""",
        RegexOption.IGNORE_CASE
    )
    private val openWords = setOf(
        "ouvre", "ouvres", "ouvrez", "ouvrir", "ouvert", "oeuvre", "lance", "lances", "lancer", "va", "vas", "aller",
        "envoie", "envoyer", "emmene", "emmener", "dirige", "redirige", "amene", "accede", "demarre", "mets", "met",
        "entre", "rentre", "retourne", "affiche"
    )
    private val openPrefix = setOf("m", "je", "veux", "vais", "faut", "faudrait", "voudrais", "peux")
    private val appFillers = setOf(
        "dans", "sur", "vers", "a", "au", "aux", "l", "la", "le", "les", "un", "une", "mon", "ma", "mes", "du", "de",
        "des", "application", "appli", "app", "moi", "donc", "s", "il", "te", "plait"
    )
    private fun isOpenWord(w: String) = w in openWords ||
        (w.length >= 4 && (Fuzzy.distance(w, "ouvre") <= 1 || Fuzzy.distance(w, "lance") <= 1))
    private val dicePlainRx = Regex("""\b(?:lance|jette|lancer)\s+(?:un|le|les)\s+des?\b""")
    private val betweenRx = Regex("""entre\s+(\d+)\s+et\s+(\d+)""")
    private val convertRx = Regex("""convertis?\s+(\d+(?:[.,]\d+)?)\s*([a-z]+)\s+en\s+([a-z]+)""")
    private val webRx1 = Regex("""^(?:cherche|recherche|trouve)\s+(.+?)\s+sur\s+(?:google|internet|le web|le net)$""")
    private val webRx2 = Regex("""^(?:recherche|cherche|google)\s+(.+)$""")
    private val frUnits = mapOf(
        "zero" to 0, "un" to 1, "une" to 1, "deux" to 2, "trois" to 3, "quatre" to 4, "cinq" to 5, "six" to 6, "sept" to 7,
        "huit" to 8, "neuf" to 9, "dix" to 10, "onze" to 11, "douze" to 12, "treize" to 13, "quatorze" to 14, "quinze" to 15, "seize" to 16
    )
    private val frTens = mapOf("vingt" to 20, "trente" to 30, "quarante" to 40, "cinquante" to 50, "soixante" to 60)

    /** « trois » → 3, « vingt et un » → 21, « quatre vingt dix » → 90… (le micro écrit les nombres en lettres). */
    private fun frNumber(words: List<String>): Int? {
        if (words.isEmpty()) return null
        words.singleOrNull()?.toIntOrNull()?.let { return it }
        var total = 0
        var any = false
        var i = 0
        while (i < words.size) {
            val w = words[i]
            when {
                w == "et" -> {}
                w == "quatre" && i + 1 < words.size && (words[i + 1] == "vingt" || words[i + 1] == "vingts") -> { total += 80; i++; any = true }
                w in frTens -> { total += frTens.getValue(w); any = true }
                w in frUnits -> { total += frUnits.getValue(w); any = true }
                else -> return null
            }
            i++
        }
        return if (any) total else null
    }

    private val tapRx = Regex("""^(?:appuie|appuyer|clique|cliquer|touche|toucher|selectionne|choisis|ouvre|va|numero)\s+(?:sur\s+)?(?:le\s+)?(?:numero\s+)?(.+)$""")
    private val clickLabelRx = Regex("""^(?:(?:appuie|appuyer|clique|cliquer|touche|toucher|tape|taper|presse|presser)\s+sur|clique|cliquer)\s+(?:(?:le|la|les|l|un|une|bouton|onglet|lien|icone|champ)\s+)*(.+)$""")
    private val longPressRx = Regex("""^(?:appuie|appuyer|maintiens|reste)\s+longtemps\s+(?:sur\s+)?(?:(?:le|la|les|l|un|une|bouton|icone)\s+)*(.+)$""")
    private val typeRx = Regex("""^(?:ecris|écris|saisis|saisir|dicte|dicter|taper|tape)\s+(?!sur\s)(.+)$""", RegexOption.IGNORE_CASE)
    private val memAddRx = Regex("""^(?:retiens|retenir|souviens[- ]toi|rappelle[- ]toi|memorise|memoriser|n'oublie pas)(?: que| de| qu')?\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val memForgetRx = Regex("""^(?:oublie|oublier)\s+(?:que\s+)?(.+)$""")
    private val personaRx = Regex("""(?:mode|personnalite|style|ton)\s+(?:de\s+)?(sarcastique|serieux|concis|court|bref|drole|humoristique|rigolo|majordome)|(?:personnalite|style|ton)\s+(?:de\s+)?(normal|neutre)|sois\s+(?:plus\s+)?(sarcastique|serieux|normal|concis|bref|drole|rigolo|humoristique|neutre)""")
    private val memStop = setOf(
        "le", "la", "les", "un", "une", "des", "de", "du", "d", "l", "est", "a", "au", "aux", "et", "ou", "que", "qui", "quoi", "quel",
        "quelle", "quels", "comment", "quand", "mon", "ma", "mes", "ton", "ta", "tes", "son", "sa", "ses", "c", "ce", "tu", "te", "t",
        "je", "j", "m", "me", "moi", "s", "il", "elle", "en", "y", "sur", "pour", "dans", "avec", "sais", "dis", "rappelle", "souviens"
    )
    private val actionVerbRx = Regex("""^(?:ouvre|ouvrir|lance|lancer|envoie|emmene|dirige|redirige|va|aller|demarre|retourne)\b""")
    private val alarmRx = Regex("""(?:alarme|reveil|reveille|reveiller)\D{0,28}?(\d{1,2})\s*(?:h|:)\s*(\d{0,2})""")
    private val inRx = Regex("""dans\s+(\d+)\s*(minutes?|min|heures?|h|secondes?|sec)\b""")
    private val callKeyRx = Regex("""^(?:(?:passe|fais|donne)\s+(?:un\s+)?(?:coup\s+de\s+fil|appel|coup\s+de\s+telephone)\s+(?:a|au|aux|pour)\s+|veux\s+(?:appeler|parler\s+a)\s+|(?:appelle|appeler|telephone\s+a|telephoner\s+a|contacte|contacter|joins|joindre|parle\s+a)\s+)(.+)$""")
    private val reminderRx = Regex("""rappelle\s+dans\s+(\d+)\s*(minutes?|min|heures?|h)\s+(?:de\s+|d |que\s+|pour\s+)?(.+)""")
    private val timerRx = Regex("""(?:minuteur|chrono\w*|timer)\s+(?:de\s+)?(\d+)\s*(minutes?|min|secondes?|sec|heures?|h)?""")
    private val noteAddRx = Regex("""^(?:note|noter|ajoute(?: une)? note|prends? (?:une )?note)\s*[:\-]?\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val calcRx = Regex("""^(?:calcule|calculer|ca fait combien|ça fait combien|combien (?:font|fait|vaut|ca fait|ça fait))\s+(.+)$""", RegexOption.IGNORE_CASE)

    fun route(rawText: String, rules: List<AutomationRule>): RouteResult {
        val text = rawText.trim()
        val b = base(text)      // sans accents ni ponctuation
        val n = Numbers.digits(clean(text))     // + sans politesse, nombres en chiffres
        val t = soft(text)      // garde majuscules/accents pour les noms

        // 1) Une règle créée par l'utilisateur correspond exactement
        rules.firstOrNull { base(it.trigger) == b || base(it.trigger) == n }?.let { return RouteResult.LocalReply(runRule(it)) }

        if (n.isEmpty()) return RouteResult.LocalReply("Oui ? Je t'écoute.")

        // 2) Arrêt / aide / identité (en premier, ce sont des phrases courtes)
        if (n == "stop" || n == "tais toi" || n == "silence" || n.startsWith("stop ")) return RouteResult.StopSpeaking
        if (b == "aide" || has(b, "que puis je dire", "que peux tu faire", "que sais tu faire", "qu est ce que tu sais faire", "qu est ce que tu peux faire", "tu sais faire quoi", "tu peux faire quoi", "tu sais faire", "tes fonctions", "tes commandes", "a quoi tu sers", "tu sers a quoi"))
            return RouteResult.LocalReply(helpText())
        if (has(b, "qui t a cree", "qui t a developpe", "qui t a fait", "qui t a fabrique", "qui est ton createur", "qui t a cree"))
            return RouteResult.LocalReply("J'ai été développé par CENTRAL-HEX 🇬🇳.")

        // 3) Actions avec paramètres
        callRx.find(t)?.let { return RouteResult.LocalReply(device.call(it.groupValues[1].trim())) }
        callKeyRx.find(n)?.let { return RouteResult.LocalReply(device.call(it.groupValues[1].trim())) }
        smsRx.find(t)?.let { return RouteResult.LocalReply(device.sendSms(it.groupValues[1].trim(), it.groupValues[2].trim())) }
        sms2Rx.find(t)?.let { return RouteResult.LocalReply(device.sendSms(it.groupValues[1].trim(), it.groupValues[2].trim())) }
        smsOpenRx.find(t)?.let { return RouteResult.LocalReply(device.sendSms(it.groupValues[1].trim(), "")) }

        reminderRx.find(n)?.let {
            val k = it.groupValues[1].toLongOrNull() ?: return@let
            val ms = if (it.groupValues[2].startsWith("h")) k * 3_600_000L else k * 60_000L
            return RouteResult.LocalReply(reminders.schedule(ms, it.groupValues[3].trim()))
        }
        timerRx.find(n)?.let {
            val k = it.groupValues[1].toLongOrNull() ?: return@let
            val unit = it.groupValues[2]
            val (ms, label) = when {
                unit.startsWith("h") -> k * 3_600_000L to "$k heure(s)"
                unit.startsWith("s") -> k * 1_000L to "$k seconde(s)"
                else -> k * 60_000L to "$k minute(s)"
            }
            return RouteResult.LocalReply(reminders.schedule(ms, "Minuteur de $label terminé."))
        }
        alarmRx.find(n)?.let {
            val h = it.groupValues[1].toIntOrNull() ?: return@let
            val m = it.groupValues[2].toIntOrNull() ?: 0
            val hour = if (h in 1..11 && has(n, "soir", "apres midi")) h + 12 else h
            if (hour in 0..23 && m in 0..59) return RouteResult.LocalReply(device.setAlarm(hour, m))
        }
        if (has(n, "previens", "prevenir", "reveil", "reveille", "alarme", "sonne", "minuteur")) inRx.find(n)?.let {
            val k = it.groupValues[1].toLongOrNull() ?: return@let
            val u = it.groupValues[2]
            val ms = when { u.startsWith("h") -> k * 3_600_000L; u.startsWith("s") -> k * 1_000L; else -> k * 60_000L }
            return RouteResult.LocalReply(reminders.schedule(ms, "C'est l'heure !"))
        }

        // 4a) Mémoire, personnalité, brief du matin (idées reprises du projet jarvis-assistant-vocal, licence MIT)
        personalFeatures(t, n, b)?.let { return RouteResult.LocalReply(it) }

        // 4) Notes
        if (has(n, "notes") && has(n, "efface", "supprime", "vide", "enleve")) return RouteResult.LocalReply(clearNotes())
        if (has(n, "notes") && (has(n, "lis", "montre", "affiche", "liste", "quelles", "voir", "ouvre") || n == "notes" || n == "mes notes"))
            return RouteResult.LocalReply(listNotes())
        noteAddRx.find(text)?.let { return RouteResult.LocalReply(addNote(it.groupValues[1].trim())) }

        // 4b) Contrôle vocal du téléphone (comme Voice Access) : accueil, retour, notifications, défilement, toucher, écrire
        controlPhone(text, t, n)?.let { return it }
        connectors(t, n)?.let { return it }

        // 5) Calcul
        calcRx.find(n)?.let { m -> Calculator.evaluate(m.groupValues[1])?.let { return RouteResult.LocalReply(it) } }

        // 5a) Calcul à la bonne franquette : « 12 fois 15 », « 20 plus 5 »
        if (Regex("\\d").containsMatchIn(n) && has(n, "plus", "moins", "fois", "divise", "multiplie"))
            Calculator.evaluate(n)?.let { return RouteResult.LocalReply(it) }

        // 5b) Pause / suivant / précédent (touches média)
        if (has(n, "suivante", "suivant", "next", "passe la chanson")) return RouteResult.LocalReply(device.mediaControl("next"))
        if (has(n, "precedente", "precedent", "revenir en arriere")) return RouteResult.LocalReply(device.mediaControl("prev"))
        if (n == "pause" || n == "play" || has(n, "mets en pause", "met en pause", "reprends la lecture", "arrete la musique", "coupe la musique", "stoppe la musique"))
            return RouteResult.LocalReply(device.mediaControl("play_pause"))

        // 5c) Vidéo (YouTube)
        videoOnYtRx.find(n)?.let { return RouteResult.LocalReply(device.searchVideo(it.groupValues[1].trim())) }
        videoRx.find(n)?.let { return RouteResult.LocalReply(device.searchVideo(it.groupValues[1].trim())) }

        // 5c2) Bonus (tout marche hors ligne)
        if (has(n, "pile ou face")) return RouteResult.LocalReply(Fun.coin())
        if (dicePlainRx.containsMatchIn(n)) return RouteResult.LocalReply(Fun.dice())
        betweenRx.find(n)?.let { m ->
            if (has(n, "nombre", "chiffre", "tire", "choisis", "hasard")) {
                val a = m.groupValues[1].toIntOrNull(); val b = m.groupValues[2].toIntOrNull()
                if (a != null && b != null) return RouteResult.LocalReply(Fun.randomBetween(a, b))
            }
        }
        if (has(n, "blague", "histoire drole", "fais rire")) return RouteResult.LocalReply(Fun.joke())
        if (has(n, "citation", "motive", "motivation")) return RouteResult.LocalReply(Fun.quote())
        if (has(n, "espace libre", "espace de stockage", "memoire libre", "stockage")) return RouteResult.LocalReply(device.storageInfo())
        convertRx.find(n)?.let { m ->
            val v = m.groupValues[1].replace(',', '.').toDoubleOrNull()
            if (v != null) Fun.convert(v, m.groupValues[2], m.groupValues[3])?.let { return RouteResult.LocalReply(it) }
        }
        if (n == "repete" || has(n, "repete ce que tu as dit", "repete la reponse", "repete ca")) {
            val last = store.load().history.lastOrNull { !it.fromUser }?.text
            return RouteResult.LocalReply(last ?: "Je n'ai encore rien dit.")
        }
        webRx1.find(n)?.let { return RouteResult.LocalReply(device.webSearch(it.groupValues[1].trim())) }
        webRx2.find(n)?.let { return RouteResult.LocalReply(device.webSearch(it.groupValues[1].trim())) }

        // 5d) Musique : "joue Burna Boy", "mets de la musique de Stromae", "joue de la musique"
        musicVerbRx.find(n)?.let { m ->
            val verb = m.groupValues[1]
            val rest = m.groupValues[2].trim()
            val generic = verb in setOf("joue", "jouer", "ecoute", "ecouter", "play")
            if (generic || musicNounRx.containsMatchIn(rest)) {
                var query = rest
                repeat(2) { query = query.replace(musicLeadRx, "").trim() }
                return RouteResult.LocalReply(device.playMusic(query))
            }
        }

        // 5e) Galerie
        if (has(n, "galerie", "mes photos", "mes images", "mes videos")) return RouteResult.LocalReply(device.openGallery())

        // 6) Infos du téléphone (fonctionnent sans connexion), par mots-clés : "quel heure fait il", "il est quelle heure"…
        if (has(n, "heure") && !has(n, "alarme", "reveil", "rappel", "minuteur")) return RouteResult.LocalReply(device.currentTime())
        if (has(n, "quel jour", "quelle date", "date d aujourd", "on est quel jour", "jour sommes", "date aujourd", "la date", "le jour")) return RouteResult.LocalReply(device.currentDate())
        if (has(n, "batterie", "pile", "pourcentage", "niveau de charge", "combien de pourcent", "reste combien")) return RouteResult.LocalReply(device.batteryStatus())

        // 7) Lampe torche
        if (has(n, "torche", "lampe", "flash", "lumiere", "eclaire", "eclairer", "y vois rien", "y voit rien")) {
            return if (has(n, "eteins", "eteint", "eteindre", "coupe", "desactive", "arrete", "ferme", "stop", "enleve"))
                RouteResult.LocalReply(device.toggleFlashlight(false))
            else RouteResult.LocalReply(device.toggleFlashlight(true))
        }

        // 8) Volume, Wi-Fi, Bluetooth, avion
        if (has(n, "volume", "le son", "du son", "plus fort", "moins fort", "trop fort", "pas assez fort")) {
            return if (has(n, "baisse", "diminue", "reduis", "moins fort", "plus bas", "descend", "trop fort"))
                RouteResult.LocalReply(device.adjustVolume(false))
            else RouteResult.LocalReply(device.adjustVolume(true))
        }
        if (has(n, "wifi", "wi fi")) return RouteResult.LocalReply(device.openSystemSettings("wifi"))
        if (has(n, "bluetooth")) return RouteResult.LocalReply(device.openSystemSettings("bluetooth"))
        if (has(n, "mode avion")) return RouteResult.LocalReply(device.openAirplaneModeSettings())

        // 9) Appareil photo, carte, musique
        if (has(n, "appareil photo", "camera", "prends une photo", "prendre une photo", "selfie")) return RouteResult.LocalReply(device.openCamera())
        if (has(n, "ou suis je", "ma position", "la carte", "maps", "google maps", "itineraire")) return RouteResult.LocalReply(device.openMap())

        // 10) Son, Ne pas déranger, verrouillage
        if (has(n, "ne pas deranger")) {
            return RouteResult.LocalReply(device.setDoNotDisturb(!has(n, "desactive", "coupe", "enleve", "arrete", "retire")))
        }
        if (has(n, "silencieux", "silence mode")) {
            return RouteResult.LocalReply(device.setRingerMode(if (has(n, "desactive", "enleve", "retire", "annule", "normal", "sors")) "normal" else "silencieux"))
        }
        if (has(n, "vibreur", "vibration")) return RouteResult.LocalReply(device.setRingerMode("vibreur"))
        if (n.startsWith("verrouille") || has(n, "bloque l ecran", "verrouiller l ecran", "eteins l ecran", "eteindre l ecran"))
            return RouteResult.LocalReply(device.lockScreen())

        // 11) Ouvrir une application (en dernier pour ne pas voler "ouvre le wifi", "ouvre la caméra"…)
        // On cherche surtout le MOT-CLÉ (ouvre / lance / va / envoie-moi dans…) puis le nom de l'appli, même mal écrit.
        val toks = n.split(" ").filter { it.isNotEmpty() }
        val oi = toks.indexOfFirst { isOpenWord(it) }
        if (oi == 0 || (oi == 1 && toks[0] in openPrefix)) {
            val phrase = toks.drop(oi + 1).filter { it !in appFillers }.joinToString(" ")
            if (phrase.isNotBlank()) return RouteResult.LocalReply(device.openApp(phrase))
        }
        openRx.find(t)?.let { return RouteResult.LocalReply(device.openApp(it.groupValues[1].trim())) }

        // 12) Une règle correspond en partie (ex. déclencheur "bonsoir" dans "bonsoir jarvis")
        rules.firstOrNull { base(it.trigger).isNotEmpty() && (b.contains(base(it.trigger)) || n.contains(base(it.trigger))) }
            ?.let { return RouteResult.LocalReply(runRule(it)) }

        // 13) Petites conversations hors-ligne (salutations, politesse...)
        OfflineBrain.answer(n)?.let { return RouteResult.LocalReply(it) }

        // 13-) Une question dont la réponse est dans ta mémoire (« comment s'appelle mon père »)
        memoryAnswer(n)?.let { return RouteResult.LocalReply(it) }

        // 13a) Le nom d'une appli dit tout seul (« facebook », « whatsapp »)
        if (toks.size in 1..3) device.openAppIfMatch(n)?.let { return RouteResult.LocalReply(it) }

        // 13b) Un ordre d'action qu'on n'a pas su exécuter : on ne laisse pas l'IA inventer une réponse
        if (actionVerbRx.containsMatchIn(n)) {
            return RouteResult.LocalReply("J'ai entendu « $text », mais je ne trouve pas quoi faire. Essaie par exemple « ouvre WhatsApp », « ouvre la galerie » ou « appelle maman ».")
        }

        // 14) Rien de reconnu : on laisse l'IA répondre (nécessite internet + une clé)
        return RouteResult.AskAi(text)
    }

    // ───────────── Mémoire à long terme ─────────────

    private fun overlap(query: List<String>, text: String): Int {
        val words = Fuzzy.clean(text).split(" ").filter { it.isNotEmpty() }
        return query.count { w -> words.any { x -> x == w || (w.length >= 5 && Fuzzy.distance(x, w) <= 1) } }
    }

    private fun memoryAnswer(n: String): String? {
        val mem = store.load().memories
        if (mem.isEmpty()) return null
        if (!has(n, "comment", "quel", "quelle", "quels", "qui", "quoi", "quand", "combien", "rappelle", "souviens", "sais tu")) return null
        val q = n.split(" ").filter { it.length >= 3 && it !in memStop }
        if (q.isEmpty()) return null
        val best = mem.maxByOrNull { overlap(q, it.text) } ?: return null
        val score = overlap(q, best.text)
        return if (score >= (if (q.size == 1) 1 else 2)) "Tu m'as dit : ${best.text}." else null
    }

    private fun morningBrief(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val hello = if (hour < 18) "Bonjour." else "Bonsoir."
        val s = store.load()
        val notes = if (s.notes.isEmpty()) "" else
            " Tu as ${s.notes.size} note${if (s.notes.size > 1) "s" else ""} : " + s.notes.takeLast(3).joinToString(", ") { it.text } + "."
        return "$hello ${device.currentTime()} ${device.currentDate()} ${device.batteryStatus()}$notes Bonne journée."
    }

    /** Souvenirs, personnalité et brief : tout marche hors ligne. Renvoie null si la phrase n'est pas concernée. */
    private fun personalFeatures(t: String, n: String, b: String): String? {
        val s = store.load()

        // retenir
        memAddRx.find(t)?.let { m ->
            val fact = m.groupValues[1].trim().trimEnd('.', '!', '?')
            if (fact.length >= 3) {
                store.save(s.copy(memories = s.memories + Memory(text = fact.replaceFirstChar { it.uppercase() })))
                return "C'est noté, je m'en souviendrai : $fact."
            }
        }
        // lister / tout oublier / oublier une chose
        if (has(b, "que sais tu de moi", "que sais tu sur moi", "qu est ce que tu sais sur moi", "de quoi tu te souviens", "tes souvenirs", "mes souvenirs", "ta memoire"))
            return if (s.memories.isEmpty()) "Je ne sais encore rien de spécial sur toi. Dis « retiens que… »."
            else "Voici ce que je sais : " + s.memories.takeLast(8).joinToString(". ") { it.text } + "."
        if (has(n, "oublie tout", "efface ta memoire", "vide ta memoire", "efface tous les souvenirs")) {
            store.save(s.copy(memories = emptyList()))
            return "J'ai tout oublié."
        }
        memForgetRx.find(n)?.let { m ->
            val q = m.groupValues[1].split(" ").filter { it.length >= 3 && it !in memStop }
            val victim = s.memories.maxByOrNull { overlap(q, it.text) }
            if (q.isNotEmpty() && victim != null && overlap(q, victim.text) >= 1) {
                store.save(s.copy(memories = s.memories.filter { it.id != victim.id }))
                return "D'accord, j'ai oublié : ${victim.text}."
            }
        }

        // personnalité
        personaRx.find(n)?.let { m ->
            val key = when (m.groupValues.drop(1).firstOrNull { it.isNotEmpty() } ?: "normal") {
                "sarcastique", "majordome" -> "sarcastique"
                "concis", "court", "bref" -> "concis"
                "drole", "humoristique", "rigolo" -> "drole"
                else -> "normal"
            }
            store.save(s.copy(settings = s.settings.copy(personality = key)))
            return when (key) {
                "sarcastique" -> "Très bien. Je serai donc votre majordome sarcastique. Quel honneur."
                "concis" -> "Compris. Court."
                "drole" -> "Parfait, je passe en mode rigolo !"
                else -> "Très bien, je reviens à mon style normal."
            }
        }

        return null
    }

    private val weatherCityRx = Regex("""\b(?:a|au|aux|pour|sur|de)\s+(?!demain|aujourd)([a-z][a-z' -]{1,30}?)(?:\s+(?:demain|aujourd hui|ce soir|maintenant))?$""")
    private val hueRooms = listOf("salle de bain", "salon", "chambre", "cuisine", "bureau", "sejour", "couloir", "salle", "entree", "garage", "terrasse", "jardin")
    private val hueColorWords = listOf("rouge", "orange", "jaune", "vert", "cyan", "bleu", "violet", "rose", "magenta", "blanc")
    private val sendVerbs = setOf("envoie", "envoyer", "poste", "poster", "ecris", "publie", "publier", "message")

    /** Météo, agenda, Hue, Discord, OBS, réveil du PC, identification de musique, brief : tout ce qui sort du téléphone. */
    private fun connectors(t: String, n: String): RouteResult? {
        val s = store.load().settings
        val toks = n.split(" ").filter { it.isNotEmpty() }

        // Brief du matin (avec la météo si une ville est renseignée)
        if (has(n, "brief", "briefing", "resume de ma journee", "programme du jour", "ma journee")) {
            val base = morningBrief()
            return if (s.city.isBlank()) RouteResult.LocalReply(base)
            else RouteResult.Async { base + " " + runCatching { Connectors.weather(s.city, false) }.getOrDefault("") }
        }

        // Météo
        if (has(n, "meteo", "quel temps", "va t il pleuvoir", "va pleuvoir", "temperature dehors", "il pleut")) {
            val city = weatherCityRx.find(n)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() } ?: s.city
            if (city.isBlank()) return RouteResult.LocalReply("Dis-moi la ville : « météo à Conakry », ou renseigne ta ville dans Réglages, Connexions.")
            val tomorrow = has(n, "demain")
            return RouteResult.Async { Connectors.weather(city, tomorrow) }
        }

        // Agenda
        if (has(n, "mon agenda", "mes rendez vous", "j ai quoi", "qu est ce que j ai", "mon programme", "mes evenements") &&
            !isOpenWord(toks.firstOrNull() ?: "")
        ) {
            if (s.icalUrl.isBlank()) return RouteResult.LocalReply("Ajoute l'adresse iCal de ton agenda dans Réglages, Connexions.")
            val offset = if (has(n, "demain")) 1 else 0
            return RouteResult.Async { Connectors.agenda(s.icalUrl, offset) }
        }

        // Philips Hue
        val room = hueRooms.firstOrNull { n.contains(it) }
        val hueConfigured = s.hueIp.isNotBlank() && s.hueKey.isNotBlank()
        val hueStrong = has(n, "philips", "ampoule", "ampoules") || toks.contains("hue") ||
            (has(n, "lumiere", "lumieres", "lampe", "eclairage") && room != null)
        if (hueStrong || (has(n, "lumieres") && hueConfigured)) {
            if (!hueConfigured) return RouteResult.LocalReply("Pour piloter tes lumières Philips Hue, renseigne le pont dans Réglages, Connexions.")
            val off = has(n, "eteins", "eteint", "eteindre", "coupe", "desactive", "ferme")
            var pct = Regex("""(\d{1,3})\s*(?:%|pour cent|pourcent)""").find(n)?.groupValues?.get(1)?.toIntOrNull()
            if (pct == null && has(n, "tamise", "plus sombre")) pct = 30
            val color = hueColorWords.firstOrNull { n.contains(it) }
            return RouteResult.Async { Connectors.hue(s, room, !off, pct, color) }
        }

        // Discord
        if (has(n, "discord")) {
            val msg = Regex("""(?i)discord[\s,:]*(?:que\s+|qu')?(.+)$""").find(t)?.groupValues?.get(1)?.trim()
            if (!msg.isNullOrBlank() && !isOpenWord(toks.firstOrNull() ?: "") || (!msg.isNullOrBlank() && toks.any { it in sendVerbs }))
                return RouteResult.Async { Connectors.discord(s.discordWebhook, msg!!) }
        }

        // OBS : live, stream, enregistrement, scène
        val obsWord = toks.contains("obs") || has(n, "le live", "mon live", "le stream", "le streaming", "l enregistrement")
        if (obsWord && has(n, "lance", "demarre", "commence", "arrete", "stoppe", "coupe", "termine", "stop", "scene")) {
            if (s.obsHost.isBlank()) return RouteResult.LocalReply("Renseigne l'adresse d'OBS dans Réglages, Connexions.")
            val stop = has(n, "arrete", "stoppe", "coupe", "termine", "stop")
            val record = has(n, "enregistrement", "enregistre")
            val scene = Regex("""(?i)sc[eè]ne\s+(.+)$""").find(t)?.groupValues?.get(1)?.trim()
            if (scene != null && !stop) return RouteResult.Async {
                val r = Connectors.obs(s.obsHost, s.obsPassword, "SetCurrentProgramScene", buildJsonObject { put("sceneName", scene) })
                if (r == "ok") "OBS passe sur la scène $scene." else "OBS : $r."
            }
            val type = when { record && stop -> "StopRecord"; record -> "StartRecord"; stop -> "StopStream"; else -> "StartStream" }
            val okMsg = when (type) {
                "StopRecord" -> "L'enregistrement est arrêté."; "StartRecord" -> "L'enregistrement démarre."
                "StopStream" -> "Le live est arrêté."; else -> "Le live démarre."
            }
            return RouteResult.Async { val r = Connectors.obs(s.obsHost, s.obsPassword, type); if (r == "ok") okMsg else "OBS : $r." }
        }

        // Réveiller le PC
        if (has(n, "allume mon pc", "reveille mon pc", "demarre mon pc", "allume l ordinateur", "reveille l ordinateur", "allume mon ordinateur", "reveille mon ordinateur")) {
            if (s.pcMac.isBlank()) return RouteResult.LocalReply("Renseigne l'adresse MAC de ton PC dans Réglages, Connexions.")
            return RouteResult.Async { Connectors.wakePc(s.pcMac) }
        }

        // Quelle est cette musique ?
        if (has(n, "shazam") || (has(n, "cette musique", "cette chanson", "ce morceau") && has(n, "quelle", "quel", "c est quoi", "identifie", "reconnais", "trouve", "nom")))
            return RouteResult.LocalReply(device.identifyMusic())

        return null
    }

    private fun addNote(text: String): String {
        if (text.isBlank()) return "Dis-moi quoi noter : « note acheter du pain »."
        val s = store.load()
        store.save(s.copy(notes = s.notes + Note(text = text)))
        return "Noté : $text"
    }

    private fun listNotes(): String {
        val notes = store.load().notes
        if (notes.isEmpty()) return "Tu n'as aucune note pour le moment."
        return "Tes notes :\n" + notes.mapIndexed { i, n -> "${i + 1}. ${n.text}" }.joinToString("\n")
    }

    private fun clearNotes(): String {
        val s = store.load()
        val n = s.notes.size
        store.save(s.copy(notes = emptyList()))
        return if (n > 0) "$n note(s) effacée(s)." else "Il n'y avait aucune note."
    }

    /** Renvoie null si la phrase n'est pas un ordre de contrôle du téléphone. */
    private fun controlPhone(raw: String, t: String, n: String): RouteResult? {
        val service = JarvisAccessibilityService.instance
        fun needService(): RouteResult {
            device.openAccessibilitySettings()
            return RouteResult.LocalReply(
                "Pour contrôler le téléphone à la voix, active JARVIS dans Paramètres, Accessibilité, JARVIS. J'ouvre les réglages. " +
                    "Si Android bloque, ouvre Infos de l'appli, menu trois points, Autoriser les paramètres restreints."
            )
        }
        fun run(block: (JarvisAccessibilityService) -> String): RouteResult =
            if (service == null) needService() else RouteResult.LocalReply(block(service))

        val toks = n.split(" ").filter { it.isNotEmpty() }
        if (toks.isEmpty()) return null

        // Accueil / retour / récentes / capture / réglages rapides
        if (n in setOf("accueil", "ecran d accueil", "menu principal", "retourne a l accueil", "retour a l accueil", "va a l accueil", "retour accueil"))
            return run { it.home() }
        if (n in setOf("retour", "reviens", "reviens en arriere", "retour arriere", "touche retour", "appuie sur retour"))
            return run { it.back() }
        if (has(n, "applications recentes", "applis recentes", "multitache") || n == "recentes")
            return run { it.recents() }
        if (has(n, "capture d ecran", "fais une capture", "prends une capture", "screenshot")) return run { it.screenshot() }
        if (has(n, "reglages rapides", "parametres rapides", "panneau rapide")) return run { it.quickSettings() }
        if (has(n, "notifications") && has(n, "affiche", "montre", "ouvre", "ouvrir", "afficher", "voir", "lis"))
            return run { it.notifications() }
        if (has(n, "menu d alimentation", "menu extinction")) return run { it.powerMenu() }

        // Vision de l'écran : lire à voix haute (hors ligne) ou résumer / expliquer / traduire avec l'IA
        if (has(n, "lis l ecran", "lis ce qui est ecrit", "lis ce qu il y a", "que dit l ecran", "lis le texte", "lis la page"))
            return run { s -> s.screenText(700).ifBlank { "Je ne vois aucun texte à lire sur cet écran." } }
        if (has(n, "resume l ecran", "explique l ecran", "traduis l ecran", "traduis ce texte", "traduis la page", "c est quoi cette erreur", "que veut dire ce message", "analyse l ecran", "resume la page", "resume cette page")) {
            if (service == null) return needService()
            val screen = service.screenText(2500)
            if (screen.isBlank()) return RouteResult.LocalReply("Je ne vois aucun texte sur cet écran.")
            return RouteResult.AskAi(raw, extra = "Texte affiché à l'écran du téléphone :\n$screen")
        }

        // Numéros à l'écran
        if (has(n, "numeros") && has(n, "cache", "masque", "enleve", "retire", "ferme")) return run { it.hideNumbers() }
        if (has(n, "numeros") && has(n, "montre", "affiche", "afficher", "active")) return run { it.showNumbers() }
        if (has(n, "numerote") || has(n, "numeroter")) return run { it.showNumbers() }

        // Défilement
        if (has(n, "defile", "scroll", "page suivante", "page precedente") || n in setOf("descends", "monte", "plus bas", "plus haut")) {
            val dir = when {
                has(n, "gauche") -> "gauche"
                has(n, "droite") -> "droite"
                has(n, "haut", "precedente") || n == "monte" -> "haut"
                else -> "bas"
            }
            return run { it.scroll(dir) }
        }

        // Écrire, effacer, valider (seulement si un champ de texte est sélectionné, sinon c'est une demande pour l'IA)
        if (service != null && service.hasFocusedInput()) {
            typeRx.find(t)?.let { m -> return RouteResult.LocalReply(service.type(m.groupValues[1].trim())) }
            if (has(n, "efface", "supprime", "vide") && has(n, "texte", "champ", "saisie")) return RouteResult.LocalReply(service.clearText())
            if (n in setOf("valide", "entree", "valider", "envoie", "recherche", "ok valide")) return RouteResult.LocalReply(service.enter())
        }

        // Appui long
        longPressRx.find(n)?.let { m -> return run { s -> s.clickLabel(m.groupValues[1].trim(), longPress = true) } }

        // Appuyer sur un numéro (« appuie sur trois ») ou sur un nom (« appuie sur OK »)
        tapRx.find(n)?.let { m ->
            val num = frNumber(m.groupValues[1].trim().split(" "))
            if (num != null && num in 1..99 && service != null && JarvisAccessibilityService.instance != null) {
                // « ouvre / va + nombre » n'a de sens qu'avec les numéros affichés
                return run { s -> s.tapNumber(num) }
            }
        }
        clickLabelRx.find(n)?.let { m -> return run { s -> s.clickLabel(m.groupValues[1].trim()) } }
        return null
    }

    private fun helpText(): String = """
        Je contrôle aussi tout le téléphone, comme Voice Access (à activer dans Accessibilité) : « accueil », « retour »,
        « affiche les notifications », « applications récentes », « défile vers le bas », « appuie sur OK »,
        « montre les numéros » puis « appuie sur 3 », « écris bonjour » dans un champ de texte.
        Avec internet et les connexions des Réglages : la météo (« météo à Conakry »), ton agenda (« qu'est-ce que j'ai demain »),
        tes lumières Philips Hue (« éteins les lumières du salon »), Discord (« envoie sur Discord… »), OBS (« lance le live »),
        réveiller ton PC (« allume mon PC »), et « c'est quoi cette musique ? ».
        Je retiens ce que tu me dis (« retiens que mon père s'appelle Mamadou ») et je m'en souviens, hors ligne.
        Je change de personnalité (« mode sarcastique », « mode concis », « mode drôle »). Je lis l'écran (« lis l'écran »)
        ou je le résume avec l'IA (« résume l'écran », « traduis l'écran »). Dis « brief du matin » pour ton résumé du jour.
        Je peux : appeler, envoyer un SMS, ouvrir n'importe quelle application, régler une alarme,
        créer des rappels et des minuteurs, prendre des notes, faire un calcul,
        te dire l'heure, la date, le niveau de batterie, allumer la lampe torche,
        régler le volume, ouvrir le Wi-Fi, le Bluetooth ou le mode avion, ouvrir
        l'appareil photo ou la carte, contrôler la musique, changer le mode sonore,
        activer Ne pas déranger, verrouiller l'écran, chercher sur le web, convertir des unités,
        lancer un dé, jouer à pile ou face, te raconter une blague, te donner une citation,
        te dire l'espace libre, répéter ma dernière réponse, et bien sûr discuter avec toi.
        Je suis JARVIS, développé par CENTRAL-HEX 🇬🇳.
    """.trimIndent().replace("\n", " ")

    private fun runRule(rule: AutomationRule): String = when (rule.actionType) {
        "open_app" -> device.openApp(rule.actionValue)
        "call" -> device.call(rule.actionValue)
        "sms" -> device.sendSms(rule.actionValue, rule.smsBody)
        "say" -> rule.actionValue
        else -> "Règle inconnue."
    }
}
