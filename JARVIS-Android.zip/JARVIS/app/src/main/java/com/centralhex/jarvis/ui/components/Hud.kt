package com.centralhex.jarvis.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.jarvis.ui.theme.HudBg
import com.centralhex.jarvis.ui.theme.HudCyan
import com.centralhex.jarvis.ui.theme.HudGold
import com.centralhex.jarvis.ui.theme.HudGreen
import com.centralhex.jarvis.ui.theme.HudPanel
import com.centralhex.jarvis.ui.theme.HudRed
import com.centralhex.jarvis.ui.theme.HudText
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

fun orbColor(state: OrbState): Color = when (state) {
    OrbState.IDLE -> HudCyan
    OrbState.LISTENING -> HudRed
    OrbState.THINKING -> HudGold
    OrbState.SPEAKING -> Color(0xFF33FFE0)
}

private const val GLYPHS = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789:.=*+-<>"

private fun hh(a: Int): Int {
    var x = a * 374761393 + 668265263
    x = (x xor (x ushr 13)) * 1274126177
    x = x xor (x ushr 16)
    return x and 0x7fffffff
}

/** Fond Matrix : une pluie de caractères verts qui tombe en continu, discrète pour garder le texte lisible. */
@Composable
fun HudBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    var clock by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) clock += (now - last) / 1_000_000_000f
                last = now
            }
        }
    }
    val paint = remember { android.graphics.Paint().apply { typeface = android.graphics.Typeface.MONOSPACE; isAntiAlias = true } }

    Box(modifier.background(HudBg)) {
        Canvas(Modifier.fillMaxSize()) {
            val cell = 15.dp.toPx()
            paint.textSize = cell * 0.95f
            val cols = (this.size.width / cell).toInt() + 1
            val rows = (this.size.height / cell).toInt() + 1
            drawIntoCanvas { canvas ->
                val nc = canvas.nativeCanvas
                for (i in 0 until cols) {
                    val speed = 3f + (hh(i) % 70) / 10f                  // lignes par seconde
                    val tail = 6 + hh(i * 7) % 9
                    val span = rows + tail
                    val head = (clock * speed + (hh(i * 13) % span)) % span
                    val headRow = head.toInt()
                    for (k in 0 until tail) {
                        val row = headRow - k
                        if (row < 0 || row >= rows) continue
                        val flicker = if (k == 0) (clock * 6).toInt() else 0
                        val ch = GLYPHS[hh(i * 131 + row * 17 + flicker) % GLYPHS.length]
                        val fade = 1f - k / tail.toFloat()
                        if (k == 0) paint.color = android.graphics.Color.argb(150, 200, 255, 215)
                        else paint.color = android.graphics.Color.argb((95 * fade).toInt(), 0, 255, 65)
                        nc.drawText(ch.toString(), i * cell, (row + 1) * cell, paint)
                    }
                }
            }
        }
        content()
    }
}

/** Fenêtre de terminal : fond presque opaque (le texte reste lisible sur la pluie de code), bord vert, coins marqués. */
fun Modifier.hudPanel(accent: Color = HudCyan): Modifier = this.drawBehind {
    drawRect(HudPanel.copy(alpha = 0.92f))
    drawRect(accent.copy(alpha = 0.55f), style = Stroke(1.dp.toPx()))
    val l = 10.dp.toPx()
    val w = 2.5.dp.toPx()
    val sw = this.size.width
    val sh = this.size.height
    drawLine(accent, Offset(0f, 0f), Offset(l, 0f), w); drawLine(accent, Offset(0f, 0f), Offset(0f, l), w)
    drawLine(accent, Offset(sw, 0f), Offset(sw - l, 0f), w); drawLine(accent, Offset(sw, 0f), Offset(sw, l), w)
    drawLine(accent, Offset(0f, sh), Offset(l, sh), w); drawLine(accent, Offset(0f, sh), Offset(0f, sh - l), w)
    drawLine(accent, Offset(sw, sh), Offset(sw - l, sh), w); drawLine(accent, Offset(sw, sh), Offset(sw, sh - l), w)
}

/** Jauge circulaire (batterie, etc.) avec le chiffre au centre. */
@Composable
fun RingGauge(fraction: Float, label: String, color: Color, diameter: Dp = 66.dp) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(800), label = "gauge")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(diameter)) {
            val stroke = 6.dp.toPx()
            val inset = stroke / 2
            drawArc(
                color.copy(alpha = 0.18f), -90f, 360f, false,
                topLeft = Offset(inset, inset), size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke)
            )
            drawArc(
                color, -90f, 360f * f, false,
                topLeft = Offset(inset, inset), size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Text(label, color = HudText, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
    }
}
