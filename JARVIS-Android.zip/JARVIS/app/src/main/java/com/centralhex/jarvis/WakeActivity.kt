package com.centralhex.jarvis

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.centralhex.jarvis.core.AiClient
import com.centralhex.jarvis.core.CommandRouter
import com.centralhex.jarvis.core.DeviceActions
import com.centralhex.jarvis.core.JarvisBus
import com.centralhex.jarvis.core.ReminderScheduler
import com.centralhex.jarvis.core.RouteResult
import com.centralhex.jarvis.core.VoiceManager
import com.centralhex.jarvis.core.WakeWordService
import com.centralhex.jarvis.data.ActivityEntry
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.LocalStore
import com.centralhex.jarvis.ui.components.ArcReactor
import com.centralhex.jarvis.ui.components.HudBackground
import com.centralhex.jarvis.ui.components.OrbState
import com.centralhex.jarvis.ui.components.orbColor
import com.centralhex.jarvis.ui.theme.HudBg
import com.centralhex.jarvis.ui.theme.HudMuted
import com.centralhex.jarvis.ui.theme.HudText
import com.centralhex.jarvis.ui.theme.JarvisTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * S'ouvre PAR-DESSUS l'écran verrouillé quand JARVIS entend son nom : le réacteur s'anime pendant qu'il
 * écoute, réfléchit et répond. Le téléphone reste verrouillé, cet écran s'affiche juste par-dessus.
 *
 * - Voix hors ligne installée : c'est le service qui écoute et répond, cet écran ne fait qu'AFFICHER l'état.
 * - Sinon (ancien mode) : cet écran écoute lui-même avec la reconnaissance de Google.
 */
class WakeActivity : ComponentActivity() {

    private lateinit var store: LocalStore
    private lateinit var router: CommandRouter
    private val ai = AiClient()
    private var voice: VoiceManager? = null
    private val handler = Handler(Looper.getMainLooper())
    private var localMode = false

    private var orbState by mutableStateOf(OrbState.LISTENING)
    private var statusText by mutableStateOf("Je vous écoute…")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showOverLockScreen()
        localMode = WakeWordService.engineActive

        if (localMode) {
            setContent { JarvisTheme { LocalWakeScreen() } }
            scheduleClose(25_000)
            return
        }

        WakeWordService.foregroundUiListening = true
        store = LocalStore(applicationContext)
        val device = DeviceActions(applicationContext)
        router = CommandRouter(device, ReminderScheduler(applicationContext), store)
        voice = VoiceManager(
            context = this,
            onResult = { text -> handleCommand(text) },
            onListeningChange = { listening -> if (listening) orbState = OrbState.LISTENING },
            onError = { statusText = it; scheduleClose(3500) }
        )
        setContent { JarvisTheme { LegacyWakeScreen() } }

        val cmd = intent.getStringExtra("cmd")
        if (!cmd.isNullOrBlank()) handleCommand(cmd) else voice?.startListening()
        scheduleClose(15000)
    }

    private fun showOverLockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }

    // ───────────── Mode « affichage seulement » (voix hors ligne) ─────────────

    @Composable
    private fun LocalWakeScreen() {
        val bus by JarvisBus.state.collectAsState()
        val line by JarvisBus.line.collectAsState()
        var seenActive by remember { mutableStateOf(false) }
        LaunchedEffect(bus) {
            if (bus != OrbState.IDLE) seenActive = true
            else if (seenActive) {
                delay(2500)
                if (JarvisBus.state.value == OrbState.IDLE) finishAndRemoveTask()
            }
        }
        WakeLayout(bus, if (line.isBlank()) "Je vous écoute…" else line, onTalk = { WakeWordService.activate(null) })
    }

    // ───────────── Ancien mode (reconnaissance de Google) ─────────────

    private fun handleCommand(text: String) {
        handler.removeCallbacksAndMessages(null)
        val s0 = store.load()
        val label = text.trim().replaceFirstChar { it.uppercase() }.take(48)
        store.save(
            s0.copy(
                history = s0.history + ChatMessage(fromUser = true, text = text),
                activityLog = (s0.activityLog + ActivityEntry(label = label)).takeLast(20)
            )
        )
        when (val result = router.route(text, store.load().rules)) {
            is RouteResult.LocalReply -> respondAndClose(result.text)
            is RouteResult.StopSpeaking -> { voice?.stopSpeaking(); scheduleClose(600) }
            is RouteResult.Async -> {
                orbState = OrbState.THINKING
                statusText = "Un instant…"
                lifecycleScope.launch {
                    val text = try { result.block() } catch (e: Exception) { "Je n'ai pas pu joindre le service." }
                    respondAndClose(text)
                }
            }
            is RouteResult.AskAi -> {
                orbState = OrbState.THINKING
                statusText = "Analyse en cours…"
                lifecycleScope.launch {
                    val s = store.load()
                    val ex = result.extraLoader?.invoke() ?: result.extra
                    val img = result.imageLoader?.invoke()
                    val res = ai.ask(s.history, s.settings, s.memories.map { it.text }, ex, img)
                    respondAndClose(res.getOrElse { it.message ?: "Je n'ai pas pu répondre." })
                }
            }
        }
    }

    private fun respondAndClose(reply: String) {
        val s = store.load()
        store.save(s.copy(history = s.history + ChatMessage(fromUser = false, text = reply)))
        orbState = OrbState.SPEAKING
        statusText = reply
        if (s.settings.autoSpeak) voice?.speak(reply)
        scheduleClose(5500)
    }

    private fun scheduleClose(delay: Long) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ finishAndRemoveTask() }, delay)
    }

    @Composable
    private fun LegacyWakeScreen() {
        WakeLayout(orbState, statusText, onTalk = {
            orbState = OrbState.LISTENING; statusText = "Je vous écoute…"
            voice?.startListening(); scheduleClose(15000)
        })
    }

    @Composable
    private fun WakeLayout(state: OrbState, text: String, onTalk: () -> Unit) {
        HudBackground(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ArcReactor(state, 280.dp)
                Spacer(Modifier.height(24.dp))
                Text("JARVIS", color = com.centralhex.jarvis.ui.theme.HudCyan, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
                Spacer(Modifier.height(10.dp))
                Text(text, color = orbColor(state), fontSize = 15.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(36.dp))
                FilledIconButton(onClick = onTalk, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Filled.Mic, contentDescription = "Parler", modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.height(18.dp))
                Image(
                    painterResource(R.drawable.jarvis_logo), contentDescription = "CENTRAL-HEX",
                    modifier = Modifier.size(52.dp).clip(CircleShape)
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        voice?.destroy()
        if (!localMode) WakeWordService.foregroundUiListening = false
    }
}
