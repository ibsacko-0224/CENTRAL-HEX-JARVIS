package com.centralhex.jarvis.ui.theme

import androidx.compose.ui.graphics.Color

// ── Palette « Matrix » : noir, vert phosphorescent, ambre et rouge pour les alertes ──
val HudBg = Color(0xFF000300)
val HudPanel = Color(0xFF021208)
val HudCyan = Color(0xFF00FF41)      // vert Matrix (accent principal)
val HudBlue = Color(0xFF0E8F2B)
val HudGold = Color(0xFFFFD84D)
val HudRed = Color(0xFFFF3B3B)
val HudGreen = Color(0xFF7CFF5B)
val HudText = Color(0xFFC8FFD4)
val HudMuted = Color(0xFF4E8F5E)
val HudLine = Color(0xFF0B4A1B)

// Anciens noms conservés (les autres écrans les utilisent), avec les nouvelles couleurs
val HexBg = HudBg
val HexSurface = Color(0xFF010A04)
val HexCard = HudPanel
val HexLine = HudLine
val HexWhite = HudText
val HexMuted = HudMuted
val HexGreen = HudGreen
val HexRed = HudRed
val HexBubbleAi = Color(0xFF03200C)
val HexBubbleUser = Color(0xFF053616)

// Thème clair supprimé : l'appli est toujours en mode HUD sombre
val HexBgLight = Color(0xFFF4F4F6)
val HexCardLight = Color(0xFFFFFFFF)
val HexLineLight = Color(0xFFE2E2E6)
val HexTextLight = Color(0xFF131316)
val HexMutedLight = Color(0xFF6B6B74)
