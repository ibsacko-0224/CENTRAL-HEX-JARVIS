package com.centralhex.jarvis.core

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File

/**
 * Reconnaissance vocale 100 % locale (sans internet, sans le service vocal de Google) :
 * écoute en continu et envoie chaque phrase comprise à [onText].
 */
class VoskEngine(
    private val modelDir: File,
    private val onText: (String) -> Unit,
    private val onReady: () -> Unit,
    private val onFail: (String) -> Unit
) {
    private var model: Model? = null
    private var service: SpeechService? = null
    private val main = Handler(Looper.getMainLooper())

    @Volatile var ready = false
        private set

    fun start() {
        Thread {
            try {
                LibVosk.setLogLevel(LogLevel.WARNINGS)
                val m = Model(modelDir.absolutePath)             // lourd : on le charge hors du thread principal
                val rec = Recognizer(m, 16000.0f)
                main.post {
                    try {
                        model = m
                        val svc = SpeechService(rec, 16000.0f)
                        service = svc
                        svc.startListening(object : org.vosk.android.RecognitionListener {
                            override fun onPartialResult(hypothesis: String?) {}
                            override fun onResult(hypothesis: String?) { deliver(hypothesis, "text") }
                            override fun onFinalResult(hypothesis: String?) { deliver(hypothesis, "text") }
                            override fun onError(exception: Exception?) { onFail(exception?.message ?: "erreur micro") }
                            override fun onTimeout() {}
                        })
                        ready = true
                        onReady()
                    } catch (e: Exception) {
                        onFail(e.message ?: "micro indisponible")
                    }
                }
            } catch (e: Throwable) {
                main.post { onFail(e.message ?: "modèle vocal illisible") }
            }
        }.start()
    }

    private fun deliver(json: String?, key: String) {
        if (json.isNullOrBlank()) return
        val text = try { JSONObject(json).optString(key, "") } catch (e: Exception) { "" }
        if (text.isNotBlank()) onText(text.trim())
    }

    /** Pendant que JARVIS parle, on coupe l'oreille pour qu'il ne s'entende pas lui-même. */
    fun pause() { service?.setPause(true) }

    fun resume() {
        service?.reset()
        service?.setPause(false)
    }

    fun shutdown() {
        ready = false
        try { service?.stop() } catch (e: Exception) {}
        try { service?.shutdown() } catch (e: Exception) {}
        try { model?.close() } catch (e: Exception) {}
        service = null; model = null
    }
}
