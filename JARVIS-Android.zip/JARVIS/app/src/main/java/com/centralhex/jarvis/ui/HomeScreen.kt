package com.centralhex.jarvis.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SignalCellular4Bar
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.centralhex.jarvis.R
import com.centralhex.jarvis.core.DeviceActions
import com.centralhex.jarvis.core.JarvisAccessibilityService
import com.centralhex.jarvis.core.JarvisBus
import com.centralhex.jarvis.core.VoskModelStore
import com.centralhex.jarvis.core.WakeWordService
import com.centralhex.jarvis.data.ActivityEntry
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.JarvisSettings
import com.centralhex.jarvis.data.Memory
import com.centralhex.jarvis.ui.components.ArcReactor
import com.centralhex.jarvis.ui.components.HudBackground
import com.centralhex.jarvis.ui.components.OrbState
import com.centralhex.jarvis.ui.components.RingGauge
import com.centralhex.jarvis.ui.components.hudPanel
import com.centralhex.jarvis.ui.components.orbColor
import com.centralhex.jarvis.ui.theme.HudBg
import com.centralhex.jarvis.ui.theme.HudCyan
import com.centralhex.jarvis.ui.theme.HudGold
import com.centralhex.jarvis.ui.theme.HudGreen
import com.centralhex.jarvis.ui.theme.HudLine
import com.centralhex.jarvis.ui.theme.HudMuted
import com.centralhex.jarvis.ui.theme.HudPanel
import com.centralhex.jarvis.ui.theme.HudRed
import com.centralhex.jarvis.ui.theme.HudText
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class QuickAction(val icon: ImageVector, val label: String, val run: () -> Unit)

private val SUGGESTIONS = listOf(
    "Appelle maman", "Quelle heure est-il", "Allume la lampe", "Joue de la musique",
    "Météo à Conakry", "Qu'est-ce que j'ai demain", "Éteins les lumières du salon", "Allume mon PC", "C'est quoi cette musique",
    "Brief du matin", "Retiens que mon frère s'appelle Ali", "Lis l'écran", "Résume l'écran", "Mode sarcastique",
    "Accueil", "Retour", "Affiche les notifications", "Défile vers le bas", "Montre les numéros",
    "Ouvre Facebook", "Ouvre le répertoire", "Ouvre la galerie", "Règle une alarme à 7h",
    "Raconte-moi une blague", "Pile ou face", "Lance un dé", "Convertis 5 km en miles",
    "Cherche la météo sur Google", "Combien d'espace libre", "Mets une vidéo de football"
)

@Composable
fun HomeScreen(viewModel: JarvisViewModel, onOpenRules: () -> Unit, onOpenSettings: () -> Unit) {
    val state by viewModel.state.collectAsState()
    val isThinking by viewModel.isThinking.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val busState by JarvisBus.state.collectAsState()
    val modelState by VoskModelStore.state.collectAsState()
    var input by remember { mutableStateOf("") }

    val context = LocalContext.current
    val device = remember { DeviceActions(context) }
    var battery by remember { mutableStateOf(device.batteryInfo()) }
    var wifi by remember { mutableStateOf(device.isWifiConnected()) }
    var mobile by remember { mutableStateOf(device.isMobileDataConnected()) }
    var engine by remember { mutableStateOf(WakeWordService.engineActive) }
    var control by remember { mutableStateOf(JarvisAccessibilityService.isRunning) }

    LaunchedEffect(Unit) {
        VoskModelStore.refresh(context)
        while (true) {
            viewModel.refreshFromDisk()
            battery = device.batteryInfo(); wifi = device.isWifiConnected(); mobile = device.isMobileDataConnected()
            engine = WakeWordService.engineActive
            control = JarvisAccessibilityService.isRunning
            kotlinx.coroutines.delay(2000)
        }
    }

    val orbState = when {
        busState != OrbState.IDLE -> busState
        isListening -> OrbState.LISTENING
        isThinking -> OrbState.THINKING
        else -> OrbState.IDLE
    }

    fun send(text: String) { if (text.isNotBlank()) { viewModel.sendMessage(text); input = "" } }
    fun fill(prefix: String) { input = prefix }

    val actions = listOf(
        QuickAction(Icons.Filled.Mic, "VOIX") { viewModel.micPressed() },
        QuickAction(Icons.Filled.Apps, "APPLIS") { fill("ouvre ") },
        QuickAction(Icons.Filled.Call, "APPELS") { fill("appelle ") },
        QuickAction(Icons.Filled.Chat, "SMS") { fill("envoie un sms à ") },
        QuickAction(Icons.Filled.Alarm, "ALARMES") { fill("règle une alarme à ") },
        QuickAction(Icons.Filled.Settings, "AUTOMATES") { onOpenRules() }
    )

    HudBackground(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = { HudTopBar(wifi, mobile, battery.percent, onOpenSettings) },
            bottomBar = { HudInputBar(input, { input = it }, orbState == OrbState.LISTENING, { viewModel.micPressed() }, { send(input) }) }
        ) { padding ->
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                item {
                    ReactorPanel(
                        orbState,
                        state.history.lastOrNull { !it.fromUser }?.text,
                        engine,
                        onTalk = { viewModel.micPressed() }
                    )
                }
                item { VoicePanel(modelState, engine, onDownload = { VoskModelStore.download(context) }) }
                item { ControlPanel(control, onEnable = { device.openAccessibilitySettings() }) }
                item { MemoryPanel(state.memories, state.settings.personality) }
                item { SystemPanel(battery, wifi, mobile) }

                item { SectionTitle("COMMANDES RAPIDES") }
                items(actions.chunked(3)) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { a -> Box(Modifier.weight(1f)) { ActionTile(a) } }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }

                item { SectionTitle("ESSAIE DE DIRE") }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(SUGGESTIONS) { s -> SuggestionChip(s) { send(s) } }
                    }
                }

                item { SectionTitle("TRANSCRIPTION") }
                item { TranscriptPanel(state.history.takeLast(6), isThinking) }
                item { LogPanel(state.activityLog) }
                item { TogglesPanel(viewModel, state.settings, device) }
                item {
                    Text(
                        "// CENTRAL-HEX :: plus qu'un assistant, une vision",
                        style = MaterialTheme.typography.labelSmall, color = HudMuted,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

/** Texte qui s'écrit lettre par lettre, avec un curseur qui clignote, comme dans un terminal. */
@Composable
private fun TypeWriter(full: String, color: Color) {
    var shown by remember(full) { mutableStateOf(0) }
    LaunchedEffect(full) {
        shown = 0
        while (shown < full.length) { kotlinx.coroutines.delay(16); shown++ }
    }
    var blink by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(500); blink = !blink } }
    Text(
        full.take(shown) + (if (blink) "█" else " "),
        color = color, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp
    )
}

@Composable
private fun SectionTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("> " + text.lowercase().replace(' ', '_'), style = MaterialTheme.typography.titleMedium, color = HudCyan)
    }
}

@Composable
private fun HudTopBar(wifi: Boolean, mobile: Boolean, battery: Int, onOpenSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(HudBg.copy(alpha = 0.9f)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painterResource(R.drawable.jarvis_logo), contentDescription = "JARVIS",
            modifier = Modifier.size(40.dp).clip(CircleShape).border(1.5.dp, HudCyan, CircleShape)
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("JARVIS", color = HudCyan, fontWeight = FontWeight.Bold, fontSize = 20.sp, letterSpacing = 4.sp)
            Text("root@central-hex:~# système_actif", style = MaterialTheme.typography.labelSmall, color = HudMuted)
        }
        Icon(
            if (wifi) Icons.Filled.Wifi else if (mobile) Icons.Filled.SignalCellular4Bar else Icons.Filled.WifiOff,
            contentDescription = null, tint = if (wifi || mobile) HudCyan else HudMuted, modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text("$battery%", style = MaterialTheme.typography.labelMedium, color = HudMuted)
        IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, contentDescription = "Réglages", tint = HudText) }
    }
}

@Composable
private fun ReactorPanel(orbState: OrbState, lastAi: String?, engine: Boolean, onTalk: () -> Unit) {
    val c = orbColor(orbState)
    Column(
        Modifier.fillMaxWidth().hudPanel(c).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ArcReactor(orbState, 230.dp)
        Spacer(Modifier.height(8.dp))
        Text(
            when (orbState) {
                OrbState.IDLE -> if (engine) "[ EN VEILLE ] dis « jarvis »" else "[ EN VEILLE ]"
                OrbState.LISTENING -> "[ ÉCOUTE ] parle…"
                OrbState.THINKING -> "[ ANALYSE ] traitement…"
                OrbState.SPEAKING -> "[ RÉPONSE ] transmission…"
            },
            color = c, style = MaterialTheme.typography.titleMedium
        )
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(HudBg.copy(alpha = 0.7f)).padding(12.dp)
        ) {
            TypeWriter("jarvis> " + (lastAi ?: "systèmes en ligne. dis « Jarvis » pour commencer."), HudText)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = onTalk, border = BorderStroke(1.dp, c), shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.Mic, contentDescription = null, tint = c, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("[ PARLER ]", color = c, letterSpacing = 3.sp)
        }
    }
}

@Composable
private fun VoicePanel(model: VoskModelStore.State, engineActive: Boolean, onDownload: () -> Unit) {
    Column(Modifier.fillMaxWidth().hudPanel(if (engineActive) HudGreen else HudGold).padding(16.dp)) {
        Text("[ MOTEUR_VOCAL ]", style = MaterialTheme.typography.titleMedium, color = HudText)
        Spacer(Modifier.height(8.dp))
        when (model) {
            is VoskModelStore.State.Downloading -> {
                Text("Téléchargement de la voix hors ligne… ${model.percent} %", color = HudText, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { model.percent / 100f }, color = HudCyan, trackColor = HudLine, modifier = Modifier.fillMaxWidth())
            }
            is VoskModelStore.State.Installed -> Text(
                if (engineActive) "● VOIX HORS LIGNE ACTIVE — dis « Jarvis », dedans comme dehors, sans internet."
                else "Voix hors ligne installée, chargement en cours…",
                color = if (engineActive) HudGreen else HudGold, style = MaterialTheme.typography.bodySmall
            )
            is VoskModelStore.State.Failed -> {
                Text("Échec : ${model.reason}. Vérifie ta connexion puis réessaie.", color = HudRed, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onDownload, border = BorderStroke(1.dp, HudCyan), shape = RoundedCornerShape(4.dp)) {
                    Text("RÉESSAYER", color = HudCyan)
                }
            }
            else -> {
                Text(
                    "Pour que JARVIS t'entende hors de l'appli et sans internet, télécharge sa voix (41 Mo, une seule fois, connexion requise).",
                    color = HudText, style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onDownload, border = BorderStroke(1.dp, HudCyan), shape = RoundedCornerShape(4.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("TÉLÉCHARGER LA VOIX (41 Mo)", color = HudCyan, letterSpacing = 1.sp)
                }
            }
        }
    }
}

@Composable
private fun ControlPanel(active: Boolean, onEnable: () -> Unit) {
    Column(Modifier.fillMaxWidth().hudPanel(if (active) HudGreen else HudGold).padding(16.dp)) {
        Text("[ CONTRÔLE_TÉLÉPHONE ]", style = MaterialTheme.typography.titleMedium, color = HudText)
        Spacer(Modifier.height(8.dp))
        if (active) {
            Text(
                "● ACTIF — dis : « accueil », « retour », « affiche les notifications », « défile vers le bas », " +
                    "« appuie sur OK », « montre les numéros » puis « appuie sur 3 », « écris bonjour ».",
                color = HudGreen, style = MaterialTheme.typography.bodySmall
            )
        } else {
            Text(
                "Comme Voice Access : JARVIS appuie, défile, revient en arrière et écrit à ta place dans toutes les applis. " +
                    "À activer une seule fois : Accessibilité ▸ JARVIS. Si Android bloque, ouvre Infos de l'appli ▸ ⋮ ▸ Autoriser les paramètres restreints.",
                color = HudText, style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onEnable, border = BorderStroke(1.dp, HudCyan), shape = RoundedCornerShape(4.dp), modifier = Modifier.fillMaxWidth()) {
                Text("ACTIVER LE CONTRÔLE VOCAL", color = HudCyan, letterSpacing = 1.sp)
            }
        }
    }
}

@Composable
private fun MemoryPanel(memories: List<Memory>, personality: String) {
    Column(Modifier.fillMaxWidth().hudPanel().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("[ MÉMOIRE ]", style = MaterialTheme.typography.titleMedium, color = HudText)
            Text("style=${personality}", style = MaterialTheme.typography.labelSmall, color = HudCyan)
        }
        Spacer(Modifier.height(8.dp))
        if (memories.isEmpty()) {
            Text(
                "Dis « Jarvis, retiens que mon père s'appelle Mamadou » : il s'en souviendra, même hors ligne.",
                color = HudMuted, style = MaterialTheme.typography.bodySmall
            )
        } else {
            memories.takeLast(4).reversed().forEach { m ->
                Text("◆ ${m.text}", color = HudText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 2.dp))
            }
            Text("${memories.size} souvenir${if (memories.size > 1) "s" else ""} · « oublie tout » pour effacer", color = HudMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun SystemPanel(battery: DeviceActions.Battery, wifi: Boolean, mobile: Boolean) {
    Row(
        Modifier.fillMaxWidth().hudPanel().padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RingGauge(
            battery.percent / 100f, "${battery.percent}%",
            if (battery.percent <= 20 && !battery.charging) HudRed else HudCyan
        )
        Spacer(Modifier.width(16.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            StatusLine("BATTERIE", if (battery.charging) "EN CHARGE" else "SUR BATTERIE", battery.charging || battery.percent > 20)
            StatusLine("WI-FI", if (wifi) "CONNECTÉ" else "HORS LIGNE", wifi)
            StatusLine("DONNÉES", if (mobile) "CONNECTÉ" else "HORS LIGNE", mobile)
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(if (ok) HudGreen else HudMuted, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text("$label ", style = MaterialTheme.typography.labelSmall, color = HudMuted)
        Text(value, style = MaterialTheme.typography.labelSmall, color = HudText)
    }
}

@Composable
private fun ActionTile(a: QuickAction) {
    Column(
        Modifier.fillMaxWidth().hudPanel().clickable { a.run() }.padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(a.icon, contentDescription = a.label, tint = HudCyan, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(6.dp))
        Text(a.label, style = MaterialTheme.typography.labelSmall, color = HudText)
    }
}

@Composable
private fun SuggestionChip(text: String, onClick: () -> Unit) {
    Text(
        "> $text",
        color = HudCyan, style = MaterialTheme.typography.labelMedium,
        modifier = Modifier
            .border(1.dp, HudLine, RoundedCornerShape(50))
            .background(HudPanel.copy(alpha = 0.8f), RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 9.dp)
    )
}

@Composable
private fun TranscriptPanel(messages: List<ChatMessage>, thinking: Boolean) {
    Column(Modifier.fillMaxWidth().hudPanel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (messages.isEmpty()) Text("Aucun échange pour le moment.", color = HudMuted, style = MaterialTheme.typography.bodySmall)
        messages.forEach { m ->
            Text(
                if (m.fromUser) "$ ${m.text}" else "jarvis> ${m.text}",
                color = if (m.fromUser) HudCyan else HudText,
                fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp,
                modifier = Modifier.widthIn(max = 600.dp)
            )
        }
        if (thinking) Text("jarvis> analyse en cours…", color = HudGold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
    }
}

@Composable
private fun LogPanel(log: List<ActivityEntry>) {
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.FRENCH) }
    Column(Modifier.fillMaxWidth().hudPanel().padding(14.dp)) {
        Text("[ JOURNAL ]", style = MaterialTheme.typography.titleMedium, color = HudText)
        Spacer(Modifier.height(8.dp))
        if (log.isEmpty()) {
            Text("Rien pour le moment.", color = HudMuted, style = MaterialTheme.typography.bodySmall)
        } else {
            log.takeLast(6).reversed().forEach { e ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(e.label, color = HudText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    Text(fmt.format(Date(e.id)), color = HudMuted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun TogglesPanel(viewModel: JarvisViewModel, settings: JarvisSettings, device: DeviceActions) {
    Column(Modifier.fillMaxWidth().hudPanel().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ToggleRow("mot_jarvis : écoute permanente", settings.wakeWordEnabled) {
            viewModel.updateSettings(settings.copy(wakeWordEnabled = it))
        }
        ToggleRow("voix_jarvis : réponses parlées", settings.autoSpeak) { viewModel.updateSettings(settings.copy(autoSpeak = it)) }
        ToggleRow("boule_flottante : sur l'écran d'accueil", settings.floatingOrb) {
            viewModel.updateSettings(settings.copy(floatingOrb = it))
            if (it && !device.canDrawOverlays()) device.requestOverlayPermission()
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = HudText, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = HudBg, checkedTrackColor = HudCyan,
                uncheckedThumbColor = HudMuted, uncheckedTrackColor = HudLine
            )
        )
    }
}

@Composable
private fun HudInputBar(
    input: String, onInputChange: (String) -> Unit, isListening: Boolean,
    onMicClick: () -> Unit, onSend: () -> Unit
) {
    Surface(color = HudBg.copy(alpha = 0.95f)) {
        Row(
            Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input, onValueChange = onInputChange, modifier = Modifier.weight(1f),
                placeholder = { Text("$ tape une commande…", color = HudMuted) },
                shape = RoundedCornerShape(2.dp), maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = HudCyan, unfocusedBorderColor = HudLine,
                    focusedTextColor = HudText, unfocusedTextColor = HudText, cursorColor = HudCyan
                )
            )
            IconButton(
                onClick = onMicClick,
                modifier = Modifier.size(46.dp).background(if (isListening) HudRed else HudCyan, RoundedCornerShape(3.dp))
            ) { Icon(if (isListening) Icons.Filled.MicOff else Icons.Filled.Mic, contentDescription = "Micro", tint = HudBg) }
            IconButton(
                onClick = onSend,
                modifier = Modifier.size(46.dp).background(HudGreen, RoundedCornerShape(3.dp))
            ) { Icon(Icons.Filled.Send, contentDescription = "Envoyer", tint = HudBg) }
        }
    }
}
