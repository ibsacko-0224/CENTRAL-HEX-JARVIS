package com.centralhex.jarvis.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.centralhex.jarvis.core.Connectors
import com.centralhex.jarvis.core.DeviceActions
import kotlinx.coroutines.launch
import com.centralhex.jarvis.data.JarvisSettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: JarvisSettings,
    onSave: (JarvisSettings) -> Unit,
    onOpenRules: () -> Unit,
    onBack: () -> Unit
) {
    var apiKey by remember { mutableStateOf(settings.aiApiKey) }
    var baseUrl by remember { mutableStateOf(settings.aiBaseUrl) }
    var model by remember { mutableStateOf(settings.aiModel) }
    var autoSpeak by remember { mutableStateOf(settings.autoSpeak) }
    var wakeWord by remember { mutableStateOf(settings.wakeWordEnabled) }
    var showKey by remember { mutableStateOf(false) }
    var city by remember { mutableStateOf(settings.city) }
    var icalUrl by remember { mutableStateOf(settings.icalUrl) }
    var hueIp by remember { mutableStateOf(settings.hueIp) }
    var hueKey by remember { mutableStateOf(settings.hueKey) }
    var discord by remember { mutableStateOf(settings.discordWebhook) }
    var obsHost by remember { mutableStateOf(settings.obsHost) }
    var obsPass by remember { mutableStateOf(settings.obsPassword) }
    var pcMac by remember { mutableStateOf(settings.pcMac) }
    var hueMsg by remember { mutableStateOf("") }
    var localUrl by remember { mutableStateOf(settings.localUrl) }
    var localModel by remember { mutableStateOf(settings.localModel) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val device = remember { DeviceActions(context) }
    var adminActive by remember { mutableStateOf(device.isDeviceAdminActive()) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("~/réglages") },
            navigationIcon = {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Retour") }
            }
        )
    }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("# Intelligence artificielle", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                "Colle une clé gratuite d'un fournisseur compatible OpenAI, par exemple Groq " +
                    "(console.groq.com) ou OpenRouter (openrouter.ai/keys). Elle reste uniquement sur ce téléphone.",
                style = MaterialTheme.typography.bodySmall
            )

            Text("Fournisseur (touche pour remplir l'adresse et le modèle) :", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    baseUrl = "https://generativelanguage.googleapis.com/v1beta/openai"; model = "gemini-2.5-flash"
                }) { Text("Gemini") }
                OutlinedButton(onClick = {
                    baseUrl = "https://api.groq.com/openai/v1"; model = "llama-3.3-70b-versatile"
                }) { Text("Groq") }
                OutlinedButton(onClick = {
                    baseUrl = "https://openrouter.ai/api/v1"; model = "openrouter/auto"
                }) { Text("OpenRouter") }
            }

            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("Clé API") },
                singleLine = true,
                visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Masquer" else "Voir") }
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Adresse de l'API") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                label = { Text("Modèle") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Divider()
            Text("# Voix", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = autoSpeak, onCheckedChange = { autoSpeak = it })
                Spacer(Modifier.width(10.dp))
                Text("JARVIS répond aussi à voix haute")
            }

            Divider()
            Text("# Mot de réveil", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = wakeWord, onCheckedChange = { wakeWord = it })
                Spacer(Modifier.width(10.dp))
                Text("JARVIS écoute en permanence, même écran éteint")
            }
            Text(
                "Dis « JARVIS » puis ta demande, sans rien toucher. Une notification discrète " +
                    "reste affichée pendant qu'il écoute (obligatoire sur Android), et ça consomme " +
                    "un peu de batterie. Sur certains téléphones, désactive l'optimisation de " +
                    "batterie pour JARVIS pour que ça marche aussi écran éteint.",
                style = MaterialTheme.typography.bodySmall
            )

            Divider()
            Text("# Verrouillage à distance", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                if (adminActive) "✅ Activé : tu peux dire « verrouille l'écran »."
                else "Nécessaire uniquement pour que JARVIS puisse verrouiller l'écran sur demande.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = {
                    if (!adminActive) context.startActivity(device.requestDeviceAdmin())
                },
                enabled = !adminActive,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (adminActive) "Déjà activé" else "Activer le verrouillage à distance") }

            Text(
                "IA locale sur ton PC (Ollama) : mets http://IP-DU-PC:11434/v1 comme adresse, laisse la clé vide, " +
                    "et mets le nom du modèle installé. Ça marche sans internet, sur ton Wi-Fi.",
                style = MaterialTheme.typography.bodySmall
            )

            Divider()
            Text("# Connexions (facultatif)", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text("Chaque connexion active des commandes vocales. Rien n'est envoyé nulle part tant que tu n'as pas rempli la case.", style = MaterialTheme.typography.bodySmall)

            OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("Ma ville (météo, brief du matin)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                value = icalUrl, onValueChange = { icalUrl = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Agenda : adresse iCal secrète") },
                supportingText = { Text("Google Agenda ▸ Paramètres ▸ ton agenda ▸ Adresse secrète au format iCal") }
            )

            Text("> Lumières Philips Hue", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(value = hueIp, onValueChange = { hueIp = it }, label = { Text("Adresse IP du pont Hue") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(
                onClick = {
                    scope.launch {
                        hueMsg = "Association en cours…"
                        Connectors.huePair(hueIp).fold(
                            onSuccess = { k -> hueKey = k; hueMsg = "Associé ✅ Touche Enregistrer pour garder la clé." },
                            onFailure = { e -> hueMsg = e.message ?: "Échec de l'association." }
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Associer le pont (appuie d'abord sur son bouton)") }
            if (hueMsg.isNotEmpty()) Text(hueMsg, style = MaterialTheme.typography.bodySmall)
            if (hueKey.isNotEmpty()) Text("Clé Hue enregistrée localement.", style = MaterialTheme.typography.bodySmall)

            OutlinedTextField(
                value = discord, onValueChange = { discord = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Discord : adresse du webhook") },
                supportingText = { Text("Salon Discord ▸ Modifier ▸ Intégrations ▸ Webhooks ▸ Copier l'URL") }
            )

            Text("> OBS (live) et réveil du PC", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(
                value = obsHost, onValueChange = { obsHost = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("OBS : adresse IP:port") },
                supportingText = { Text("Exemple 192.168.1.20:4455 (OBS ▸ Outils ▸ Paramètres du serveur WebSocket)") }
            )
            OutlinedTextField(
                value = obsPass, onValueChange = { obsPass = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("OBS : mot de passe") }, visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                value = pcMac, onValueChange = { pcMac = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Adresse MAC du PC (réveil à distance)") },
                supportingText = { Text("Exemple AA:BB:CC:DD:EE:FF — Wake-on-LAN activé dans le BIOS du PC") }
            )

            Divider()
            Text("# Moteur d'IA", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                "Cloud : IA en ligne (Gemini, Groq…). Local : l'IA de ton PC (Ollama), sans internet. " +
                    "Hybride : cloud d'abord, ton PC si internet tombe. Tu peux aussi dire « mode local ».",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("cloud" to "Cloud", "local" to "Local", "hybride" to "Hybride").forEach { (key, label) ->
                    FilterChip(selected = settings.aiMode == key, onClick = { onSave(settings.copy(aiMode = key)) }, label = { Text(label) })
                }
            }
            OutlinedTextField(
                value = localUrl, onValueChange = { localUrl = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Serveur local : http://IP-DU-PC:11434/v1") }
            )
            OutlinedTextField(
                value = localModel, onValueChange = { localModel = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Modèle local (ex. llama3.2)") }
            )

            Divider()
            Text("# Automatismes et sécurité", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = settings.presence, onCheckedChange = { onSave(settings.copy(presence = it)) })
                Spacer(Modifier.width(10.dp))
                Text("Présence : « bon retour » et lumières quand le Wi-Fi revient, lumières éteintes quand il part", style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = settings.dailyBrief, onCheckedChange = { onSave(settings.copy(dailyBrief = it)) })
                Spacer(Modifier.width(10.dp))
                Text("Brief parlé au premier déverrouillage du matin (une fois par jour)", style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = settings.bridge, onCheckedChange = { onSave(settings.copy(bridge = it)) })
                Spacer(Modifier.width(10.dp))
                Text("Pont : Tasker et les routines peuvent envoyer des commandes à JARVIS (action com.centralhex.jarvis.COMMAND, extra « text »)", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                if (settings.alwaysAllow.isBlank()) "Sécurité : JARVIS demande « oui » avant d'envoyer un SMS, de poster sur Discord ou de modifier ton agenda."
                else "Sans confirmation (toujours autorisé) : ${settings.alwaysAllow}",
                style = MaterialTheme.typography.bodySmall
            )
            if (settings.alwaysAllow.isNotBlank()) {
                OutlinedButton(onClick = { onSave(settings.copy(alwaysAllow = "")) }, modifier = Modifier.fillMaxWidth()) { Text("Redemander confirmation partout") }
            }

            Divider()
            Text("# Personnalité de JARVIS", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text("Change le style de ses réponses (avec l'IA). Tu peux aussi le dire : « mode sarcastique ».", style = MaterialTheme.typography.bodySmall)
            val styles = listOf("normal" to "Normal", "sarcastique" to "Majordome sarcastique", "concis" to "Concis", "drole" to "Drôle")
            styles.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (key, label) ->
                        FilterChip(
                            selected = settings.personality == key,
                            onClick = { onSave(settings.copy(personality = key)) },
                            label = { Text(label) }
                        )
                    }
                }
            }

            Divider()
            Text("# Réveil « JARVIS » (écran éteint)", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                if (com.centralhex.jarvis.core.WakeWordService.isRunning) "✅ L'écoute est active (notification « JARVIS veille »)."
                else "❌ L'écoute n'est pas active. Active « Mot JARVIS » sur l'accueil.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = { device.requestIgnoreBatteryOptimizations() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Empêcher la mise en veille de JARVIS") }
            Text(
                "Pour qu'il lance des applis, la caméra ou YouTube quand tu lui parles hors de l'appli, " +
                    "autorise-le à s'afficher par-dessus les autres applis.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = { device.requestOverlayPermission() },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (device.canDrawOverlays()) "✅ Affichage par-dessus les autres applis : autorisé" else "Autoriser l'affichage par-dessus les autres applis") }

            Divider()
            Text("# Permissions (SMS, micro, plein écran…)", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Text(
                "Si l'envoi de SMS est bloqué : ouvre les paramètres de l'appli, touche le menu ⋮ en haut à droite, " +
                    "choisis « Autoriser les paramètres restreints », puis Autorisations ▸ SMS ▸ Autoriser.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = { device.openAppSettings() },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Ouvrir les paramètres de JARVIS") }

            Divider()
            OutlinedButton(onClick = onOpenRules, modifier = Modifier.fillMaxWidth()) {
                Text("Gérer les automatisations")
            }

            Button(
                onClick = {
                    onSave(
                        settings.copy(
                            aiApiKey = apiKey.trim(), aiBaseUrl = baseUrl.trim(), aiModel = model.trim(),
                            autoSpeak = autoSpeak, wakeWordEnabled = wakeWord,
                            city = city.trim(), icalUrl = icalUrl.trim(), hueIp = hueIp.trim(), hueKey = hueKey.trim(),
                            discordWebhook = discord.trim(), obsHost = obsHost.trim(), obsPassword = obsPass, pcMac = pcMac.trim(),
                            localUrl = localUrl.trim(), localModel = localModel.trim()
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Enregistrer") }

            Text(
                "// CENTRAL-HEX 🇬🇳 :: plus qu'un assistant, une vision",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
