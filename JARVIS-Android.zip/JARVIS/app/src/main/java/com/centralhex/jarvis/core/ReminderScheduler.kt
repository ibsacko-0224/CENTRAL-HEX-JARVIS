package com.centralhex.jarvis.core

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Programme un rappel : JARVIS enverra une notification au moment demandé,
 * même si l'application est fermée.
 */
class ReminderScheduler(private val context: Context) {

    fun schedule(delayMillis: Long, message: String): String {
        val am = context.getSystemService(AlarmManager::class.java)
        val requestCode = System.currentTimeMillis().toInt()
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("message", message)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pending = PendingIntent.getBroadcast(context, requestCode, intent, flags)
        val triggerAt = System.currentTimeMillis() + delayMillis

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.set(AlarmManager.RTC_WAKEUP, triggerAt, pending) // approximatif si la permission exacte manque
            return "Permission des alarmes précises non accordée : le rappel sera approximatif."
        }
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        return "D'accord, je te le rappelle."
    }
}
