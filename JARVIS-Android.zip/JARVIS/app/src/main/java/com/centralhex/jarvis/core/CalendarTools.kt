package com.centralhex.jarvis.core

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * L'agenda du téléphone : lit et écrit dans TOUS les agendas synchronisés (Google, abonnements iCal, Samsung…)
 * sans connexion Google à configurer. Il faut juste autoriser l'accès au calendrier.
 */
object CalendarTools {

    data class Ev(val id: Long, val title: String, val begin: Long, val allDay: Boolean)

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun midnight(offsetDays: Int): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, offsetDays)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun events(ctx: Context, start: Long, end: Long): List<Ev> {
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, start)
        ContentUris.appendId(builder, end)
        val proj = arrayOf(
            CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY
        )
        val out = mutableListOf<Ev>()
        ctx.contentResolver.query(builder.build(), proj, null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
            while (c.moveToNext()) {
                out.add(Ev(c.getLong(0), c.getString(1)?.takeIf { it.isNotBlank() } ?: "(sans titre)", c.getLong(2), c.getInt(3) == 1))
            }
        }
        return out
    }

    private fun label(e: Ev, withDay: Boolean): String {
        val day = SimpleDateFormat("EEEE", Locale.FRENCH).format(Date(e.begin))
        val time = if (e.allDay) "toute la journée" else SimpleDateFormat("HH'h'mm", Locale.FRENCH).format(Date(e.begin))
        return (if (withDay) "$day " else "") + "$time ${e.title}"
    }

    fun summary(ctx: Context, dayOffset: Int, days: Int): String {
        val list = events(ctx, midnight(dayOffset), midnight(dayOffset + days))
        val word = when {
            days > 1 -> "Cette semaine"
            dayOffset == 0 -> "Aujourd'hui"
            dayOffset == 1 -> "Demain"
            else -> "Ce jour-là"
        }
        if (list.isEmpty()) return "Rien de prévu ${word.lowercase()}."
        return "$word tu as ${list.size} événement${if (list.size > 1) "s" else ""} : " +
            list.take(10).joinToString(", ") { label(it, days > 1) } + "."
    }

    private fun writableCalendarId(ctx: Context): Long? {
        val proj = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY)
        val sel = "${CalendarContract.Calendars.VISIBLE} = 1 AND ${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"
        var first: Long? = null
        ctx.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, proj, sel, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (first == null) first = id
                if (c.getInt(1) == 1) return id
            }
        }
        return first
    }

    fun create(ctx: Context, title: String, begin: Long, durationMin: Int = 60): String {
        val cal = writableCalendarId(ctx) ?: return "Je ne trouve aucun agenda où écrire. Ajoute un compte Google dans les paramètres du téléphone."
        val v = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, cal)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DTSTART, begin)
            put(CalendarContract.Events.DTEND, begin + durationMin * 60_000L)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        return if (ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v) != null) "C'est ajouté à ton agenda." else "Je n'ai pas pu ajouter l'événement."
    }

    /** L'événement des 90 prochains jours dont le titre ressemble le plus à [query]. */
    fun findUpcoming(ctx: Context, query: String): Ev? {
        val list = events(ctx, System.currentTimeMillis(), System.currentTimeMillis() + 90L * 86_400_000L)
        val best = list.maxByOrNull { Fuzzy.similarity(query, it.title) } ?: return null
        return if (Fuzzy.similarity(query, best.title) >= 0.6) best else null
    }

    fun delete(ctx: Context, e: Ev): String {
        val n = ctx.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, e.id), null, null)
        return if (n > 0) "J'ai supprimé « ${e.title} »." else "Je n'ai pas pu le supprimer."
    }

    fun describe(e: Ev): String = SimpleDateFormat("EEEE d MMMM 'à' HH'h'mm", Locale.FRENCH).format(Date(e.begin))

    // ───────────── Comprendre « demain à 15h » ─────────────

    private val weekdays = listOf("dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi")

    /** Date + heure dites dans la phrase (texte nettoyé, nombres en chiffres). Heure par défaut : 9h. */
    fun parseWhen(n: String): Long {
        val cal = Calendar.getInstance()
        val now = Calendar.getInstance()
        when {
            n.contains("apres demain") -> cal.add(Calendar.DAY_OF_YEAR, 2)
            n.contains("demain") -> cal.add(Calendar.DAY_OF_YEAR, 1)
            else -> {
                val wd = weekdays.indexOfFirst { n.contains(it) }
                if (wd >= 0) {
                    val today = now.get(Calendar.DAY_OF_WEEK) - 1
                    var diff = (wd - today + 7) % 7
                    if (diff == 0) diff = 7
                    cal.add(Calendar.DAY_OF_YEAR, diff)
                } else {
                    Regex("""\ble (\d{1,2})\b(?!\s*h)""").find(n)?.groupValues?.get(1)?.toIntOrNull()?.let { d ->
                        if (d in 1..31) {
                            cal.set(Calendar.DAY_OF_MONTH, d)
                            if (cal.before(now)) cal.add(Calendar.MONTH, 1)
                        }
                    }
                }
            }
        }
        val m = Regex("""(\d{1,2})h(\d{2})?""").find(n)
        var hour = m?.groupValues?.get(1)?.toIntOrNull() ?: 9
        val minute = m?.groupValues?.get(2)?.toIntOrNull() ?: 0
        if (hour in 1..11 && (n.contains("soir") || n.contains("apres midi"))) hour += 12
        cal.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23)); cal.set(Calendar.MINUTE, minute.coerceIn(0, 59))
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private val fillers = setOf(
        "ajoute", "cree", "programme", "planifie", "mets", "met", "note", "inscris", "prevois", "supprime", "annule", "efface", "enleve", "retire",
        "rendez", "vous", "rdv", "evenement", "reunion", "agenda", "calendrier", "mon", "ma", "mes", "a", "au", "dans", "pour", "le", "la", "les",
        "un", "une", "de", "du", "des", "demain", "aujourd", "hui", "apres", "ce", "soir", "matin", "midi", "avec", "sur", "prochain", "prochaine"
    ) + weekdays

    /** Le titre qui reste quand on retire les mots de commande, la date et l'heure. */
    fun titleOf(n: String): String {
        val cleaned = n.replace(Regex("""\d{1,2}h(\d{2})?"""), " ").replace(Regex("""\ble \d{1,2}\b"""), " ")
        return cleaned.split(" ").filter { it.isNotBlank() && it !in fillers }.joinToString(" ")
    }
}
