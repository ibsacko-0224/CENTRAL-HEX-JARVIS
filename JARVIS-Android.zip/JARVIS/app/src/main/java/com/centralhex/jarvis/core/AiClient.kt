package com.centralhex.jarvis.core

import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.JarvisSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Appelle une IA compatible avec le format OpenAI (Groq, OpenRouter, etc.).
 * Aucune clé n'est écrite dans le code : la personne la colle dans Réglages,
 * elle reste stockée uniquement sur son téléphone.
 */
class AiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val persona = """
        Tu es JARVIS, l'assistant personnel du propriétaire de ce téléphone Android,
        développé par CENTRAL-HEX 🇬🇳. Si on te demande qui t'a créé ou développé,
        réponds que c'est CENTRAL-HEX. Réponds dans la langue utilisée par la personne
        (français par défaut), de façon directe, utile et un peu posée, comme un
        majordome efficace. Garde tes réponses courtes (elles peuvent être lues à
        voix haute), sauf si on te demande des détails. Tu n'as pas de corps ni de
        capacités en dehors de ce téléphone : ne prétends pas agir sur le monde réel
        au-delà de ce que l'application te permet (appeler, envoyer un SMS, ouvrir
        une appli, régler un rappel, prendre une note, faire un calcul).
        IMPORTANT : tu n'exécutes AUCUNE action toi-même. Les ordres (ouvrir une appli, appeler,
        envoyer, allumer la lampe…) sont traités par l'application avant toi. Ne dis donc JAMAIS
        « j'ouvre », « je t'envoie », « j'appelle » ou « c'est fait ». Si on te demande une action,
        réponds seulement que tu n'as pas compris et propose la formulation « ouvre <nom de l'appli> ».
        Ne réponds qu'à ce qui t'est demandé, sans rien inventer.
    """.trimIndent()

    companion object {
        /** Modèle trouvé automatiquement quand celui des Réglages n'existe plus chez le fournisseur. */
        @Volatile var discoveredModel: String? = null
    }

    private val unwanted = listOf("whisper", "guard", "tts", "playai", "embed", "orpheus", "moderation", "safeguard", "vision-preview", "embedding", "imagen", "veo", "image", "aqa", "audio", "learnlm")
    private val preferred = listOf("gemini-2.5-flash", "gemini-flash", "gemini-2.0-flash", "gemini", "llama-3.3-70b", "llama-3.1-8b-instant", "gpt-oss-120b", "gpt-oss-20b", "llama-4", "llama3", "qwen", "gemma", "mixtral")

    /** Demande au fournisseur la liste de ses modèles et choisit un modèle de discussion disponible. */
    private fun discoverModel(settings: JarvisSettings): String? = try {
        val req = Request.Builder()
            .url(settings.aiBaseUrl.trimEnd('/') + "/models")
            .addHeader("Authorization", "Bearer " + settings.aiApiKey.ifBlank { "local" })
            .get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) null else {
                val ids = Json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject["data"]
                    ?.jsonArray?.mapNotNull { it.jsonObject["id"]?.jsonPrimitive?.contentOrNull?.removePrefix("models/") }
                    ?.filter { id -> unwanted.none { id.contains(it, ignoreCase = true) } }
                    .orEmpty()
                preferred.firstNotNullOfOrNull { p -> ids.firstOrNull { it.contains(p, ignoreCase = true) } } ?: ids.firstOrNull()
            }
        }
    } catch (e: Exception) { null }

    private fun friendlyError(code: Int, body: String): String = when (code) {
        401, 403 -> "Clé IA refusée. Vérifie qu'elle est bien copiée en entier dans Réglages."
        429 -> "Limite gratuite atteinte pour le moment. Réessaie dans une minute."
        in 500..599 -> "Le service d'IA est en panne pour le moment. Réessaie plus tard."
        else -> "Erreur IA ($code) : ${body.take(120)}"
    }

    private fun styleOf(personality: String) = when (personality) {
        "sarcastique" -> "\nStyle : tu es un majordome britannique pince-sans-rire, très poli mais légèrement sarcastique, toujours bref."
        "concis" -> "\nStyle : réponds en UNE phrase courte maximum, sans détour."
        "drole" -> "\nStyle : tu es plein d'humour et tu glisses une petite touche amusante, sans jamais être long."
        else -> ""
    }

    suspend fun ask(
        history: List<ChatMessage>, settings: JarvisSettings,
        memories: List<String> = emptyList(), extra: String? = null
    ): Result<String> =
        withContext(Dispatchers.IO) {
            if (settings.aiApiKey.isBlank() && !settings.aiBaseUrl.trim().startsWith("http://")) {
                return@withContext Result.failure(
                    IllegalStateException("J'ai entendu « ${history.lastOrNull { it.fromUser }?.text.orEmpty()} », mais je ne sais pas encore faire ça. Dis « aide » pour voir mes commandes. Pour les questions libres, ajoute une clé IA gratuite dans Réglages.")
                )
            }
            try {
                val messages = buildJsonArray {
                    val memBlock = if (memories.isEmpty()) "" else
                        "\nCe que tu sais sur l'utilisateur (utilise-le seulement si c'est utile) :\n" + memories.joinToString("\n") { "- $it" }
                    add(buildJsonObject { put("role", "system"); put("content", persona + styleOf(settings.personality) + memBlock) })
                    val recent = history.takeLast(16)
                    recent.forEachIndexed { i, m ->
                        add(buildJsonObject {
                            put("role", if (m.fromUser) "user" else "assistant")
                            // le texte de l'écran (si demandé) s'ajoute au dernier message de l'utilisateur
                            put("content", if (extra != null && i == recent.lastIndex && m.fromUser) m.text + "\n\n" + extra else m.text)
                        })
                    }
                }

                fun call(model: String): Pair<Int, String> {
                    val payload = buildJsonObject {
                        put("model", model)
                        put("temperature", 0.6)
                        put("max_tokens", 500)
                        put("messages", messages)
                    }.toString()
                    val request = Request.Builder()
                        .url(settings.aiBaseUrl.trimEnd('/') + "/chat/completions")
                        .addHeader("Authorization", "Bearer " + settings.aiApiKey.ifBlank { "local" })
                        .post(payload.toRequestBody("application/json".toMediaType()))
                        .build()
                    return client.newCall(request).execute().use { resp -> resp.code to resp.body?.string().orEmpty() }
                }

                var (code, body) = call(discoveredModel ?: settings.aiModel)
                // Modèle supprimé ou inaccessible : on en cherche un autre automatiquement, une seule fois.
                if (code == 404 || (code == 400 && body.contains("model", ignoreCase = true))) {
                    val found = discoverModel(settings)
                    if (found != null) { discoveredModel = found; val r = call(found); code = r.first; body = r.second }
                }
                if (code !in 200..299) return@withContext Result.failure(Exception(friendlyError(code, body)))

                val root = Json.parseToJsonElement(body).jsonObject
                val text = root["choices"]?.jsonArray?.firstOrNull()
                    ?.jsonObject?.get("message")?.jsonObject?.get("content")
                    ?.jsonPrimitive?.contentOrNull
                if (text.isNullOrBlank()) Result.failure(Exception("Réponse vide de l'IA."))
                else Result.success(text.trim())
            } catch (e: java.io.IOException) {
                Result.failure(Exception("Pas de connexion internet : j'ai entendu « ${history.lastOrNull { it.fromUser }?.text.orEmpty()} », mais cette question a besoin d'internet. Mes commandes du téléphone marchent hors ligne : dis « aide »."))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
