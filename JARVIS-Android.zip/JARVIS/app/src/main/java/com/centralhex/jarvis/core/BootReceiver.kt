package com.centralhex.jarvis.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.centralhex.jarvis.MainActivity
import com.centralhex.jarvis.data.LocalStore

/** Android 14+ interdit de relancer un service micro au démarrage : on envoie donc une notification à toucher. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!LocalStore(context.applicationContext).load().settings.wakeWordEnabled) return
        val ok = try { WakeWordService.start(context.applicationContext); true } catch (e: Exception) { false }
        if (ok) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel("jarvis_boot", "Démarrage de JARVIS", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val pi = PendingIntent.getActivity(
            context, 7, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            77,
            NotificationCompat.Builder(context, "jarvis_boot")
                .setSmallIcon(android.R.drawable.presence_audio_online)
                .setContentTitle("JARVIS")
                .setContentText("Touche pour réactiver l'écoute « Jarvis ».")
                .setContentIntent(pi).setAutoCancel(true).build()
        )
    }
}
