package com.centralhex.jarvis.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.centralhex.jarvis.data.ChatMessage
import com.centralhex.jarvis.data.LocalStore

/**
 * Le « pont » : une autre appli (Tasker, routines Samsung, Google Assistant, un raccourci…) peut envoyer
 *   action : com.centralhex.jarvis.COMMAND      extra « text » : la commande en français
 * Désactivé par défaut (Réglages ▸ Pont), pour qu'aucune appli inconnue ne puisse piloter JARVIS.
 */
class CommandReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text")?.trim().orEmpty()
        if (text.isEmpty()) return
        val store = LocalStore(context.applicationContext)
        if (!store.load().settings.bridge) return
        // Si l'écoute tourne, JARVIS répond comme si tu lui avais parlé ; sinon on note juste la commande.
        if (!WakeWordService.runCommand(text)) {
            val s = store.load()
            store.save(s.copy(history = s.history + ChatMessage(fromUser = true, text = text)))
        }
    }
}
