package com.centralhex.jarvis.core

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import com.centralhex.jarvis.R
import com.centralhex.jarvis.ui.components.OrbState
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * La boule : une goutte de cristal bleu-blanc qui ondule comme de l'eau, avec des paillettes, des reflets qui
 * tournent et un éclat de lumière, le logo JARVIS en son centre, et un « boum » quand il répond oui.
 */
@SuppressLint("ViewConstructor")
class OrbView(context: Context) : View(context) {

    private val d = resources.displayMetrics.density
    private var clock = 0f
    private var amp = 1f
    private var burst = 1f                       // 0 → 1 pendant l'animation « oui » ; 1 = repos
    private var state = OrbState.IDLE
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spark = Paint(Paint.ANTI_ALIAS_FLAG)
    private val logoMatrix = Matrix()
    private val rimMatrix = Matrix()
    private val blob = Path()
    private var logoShader: BitmapShader? = null
    private var logoSize = 0
    private var rimShader: SweepGradient? = null

    // 16 paillettes qui flottent autour de la goutte
    private val rnd = java.util.Random(7)
    private val sparkAngle = FloatArray(16) { rnd.nextFloat() * 6.2832f }
    private val sparkRadius = FloatArray(16) { 0.55f + rnd.nextFloat() * 0.75f }
    private val sparkSpeed = FloatArray(16) { (0.12f + rnd.nextFloat() * 0.3f) * (if (rnd.nextBoolean()) 1 else -1) }
    private val sparkSize = FloatArray(16) { 0.8f + rnd.nextFloat() * 1.6f }
    private val sparkPhase = FloatArray(16) { rnd.nextFloat() * 6.2832f }

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            val active = state != OrbState.IDLE
            clock += if (active) 0.085f else 0.04f
            amp += ((if (active) 1.8f else 1f) - amp) * 0.06f
            invalidate()
        }
    }

    /** L'animation « Oui, je suis là » : ondes de choc, logo qui gonfle, éclair de lumière. */
    private fun playActivate() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 750
            interpolator = android.view.animation.DecelerateInterpolator()
            addUpdateListener { burst = it.animatedValue as Float; invalidate() }
        }.start()
    }

    fun setOrbState(s: OrbState) {
        if (s == state) return
        val previous = state
        state = s
        rimShader = null
        if (s == OrbState.LISTENING && previous != OrbState.LISTENING) playActivate()
        animate().scaleX(1.18f).scaleY(1.18f).setDuration(110).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(2.2f)).start()
        }.start()
    }

    /** Teinte de la goutte selon l'état : bleu cristal au repos. */
    private fun tint() = when (state) {
        OrbState.IDLE -> Color.rgb(0, 255, 65)
        OrbState.LISTENING -> Color.rgb(255, 59, 59)
        OrbState.THINKING -> Color.rgb(255, 216, 77)
        OrbState.SPEAKING -> Color.rgb(51, 255, 224)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); animator.start() }
    override fun onDetachedFromWindow() { animator.cancel(); super.onDetachedFromWindow() }

    private fun ensureLogo(diameter: Int) {
        if (diameter <= 0 || logoSize == diameter) return
        val src = BitmapFactory.decodeResource(resources, R.drawable.jarvis_logo) ?: return
        val bmp = Bitmap.createScaledBitmap(src, diameter, diameter, true)
        logoShader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        logoSize = diameter
    }

    /** Contour ondulé de la goutte ; [ripple] ajoute les petites vagues serrées de l'eau. */
    private fun buildBlob(cx: Float, cy: Float, r: Float, t: Float, seed: Float, ripple: Boolean) {
        blob.reset()
        val n = 120
        for (i in 0..n) {
            val a = i * 6.2831855f / n
            var k = 1f + amp * (
                0.055f * sin(2 * a + t + seed) +
                    0.040f * sin(3 * a - 1.3f * t + seed * 2f) +
                    0.022f * sin(5 * a + 1.9f * t)
                )
            if (ripple) k += amp * (0.014f * sin(9 * a + 3.1f * t + seed) + 0.010f * sin(13 * a - 4.2f * t + seed))
            val x = cx + r * k * cos(a)
            val y = cy + r * k * sin(a) * 1.05f
            if (i == 0) blob.moveTo(x, y) else blob.lineTo(x, y)
        }
        blob.close()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val ro = width / 2f - 14f * d
        val big = ro * 0.92f
        val tn = tint()
        val tr = Color.red(tn); val tg = Color.green(tn); val tb = Color.blue(tn)
        val t = clock

        // ondes de choc du « oui »
        if (burst < 1f) {
            for (i in 0 until 3) {
                val p = (burst * 1.3f - i * 0.16f).coerceIn(0f, 1f)
                if (p <= 0f || p >= 1f) continue
                stroke.shader = null
                stroke.color = Color.argb(((1f - p) * 235).toInt(), 190, 255, 205)
                stroke.strokeWidth = (5f * (1f - p) + 1f) * d
                canvas.drawCircle(cx, cy, ro * (0.85f + 0.5f * p), stroke)
            }
        }
        // lueur autour de la goutte (un éclair pendant le « oui »)
        val flash = if (burst < 1f) (1f - burst) else 0f
        fill.shader = RadialGradient(
            cx, cy, ro * 1.3f,
            intArrayOf(Color.argb((95 + 140 * flash).toInt().coerceAtMost(240), tr, tg, tb), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, ro * 1.3f, fill)

        // corps : fond sombre au centre, bords de cristal clairs
        buildBlob(cx, cy, big, t, 0f, false)
        fill.shader = null
        fill.color = Color.argb(235, 0, 8, 2)
        canvas.drawPath(blob, fill)
        fill.shader = RadialGradient(
            cx, cy, big * 1.1f,
            intArrayOf(Color.TRANSPARENT, Color.argb(70, tr, tg, tb), Color.argb(210, 190, 255, 205)),
            floatArrayOf(0.42f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawPath(blob, fill)
        fill.shader = null

        // logo JARVIS au centre (qui gonfle pendant le « oui »)
        val rl = big * 0.60f
        ensureLogo((rl * 2).toInt())
        logoShader?.let { sh ->
            val pop = 1f + 0.22f * sin(burst * 3.1416f)
            logoMatrix.setTranslate(cx - rl, cy - rl)
            sh.setLocalMatrix(logoMatrix)
            fill.shader = sh
            canvas.save()
            canvas.scale(pop, pop, cx, cy)
            canvas.drawCircle(cx, cy, rl, fill)
            canvas.restore()
            fill.shader = null
        }

        // reflets de cristal : plusieurs contours ondulés où la lumière glisse
        if (rimShader == null) {
            rimShader = SweepGradient(
                cx, cy,
                intArrayOf(
                    Color.TRANSPARENT, Color.rgb(255, 255, 255), Color.TRANSPARENT, Color.rgb(tr, tg, tb),
                    Color.TRANSPARENT, Color.argb(200, 255, 255, 255), Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.10f, 0.25f, 0.50f, 0.62f, 0.80f, 1f)
            )
        }
        val rim = rimShader!!
        for (i in 0 until 3) {
            buildBlob(cx, cy, big * (1f - 0.035f * i), t * (1f + 0.25f * i), i * 1.9f, true)
            rimMatrix.setRotate((t * 38f + i * 120f) * (if (i % 2 == 0) 1f else -1f), cx, cy)
            rim.setLocalMatrix(rimMatrix)
            stroke.shader = rim
            stroke.strokeWidth = (2.6f - 0.6f * i) * d
            stroke.alpha = 255 - i * 55
            canvas.drawPath(blob, stroke)
        }
        stroke.shader = null

        // éclat de lumière en diagonale
        val gl = 0.55f + 0.45f * sin(t * 1.4f)
        stroke.shader = LinearGradient(
            cx + ro * 0.15f, cy + ro * 0.15f, cx + ro * 1.3f, cy + ro * 1.3f,
            Color.argb((200 * gl).toInt(), 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        stroke.strokeWidth = 2.2f * d
        stroke.alpha = 255
        canvas.drawLine(cx + ro * 0.15f, cy + ro * 0.15f, cx + ro * 1.3f, cy + ro * 1.3f, stroke)
        stroke.shader = null

        // paillettes
        for (i in sparkAngle.indices) {
            val ang = sparkAngle[i] + t * sparkSpeed[i]
            val rr = ro * sparkRadius[i]
            val tw = abs(sin(t * 2.2f + sparkPhase[i]))
            spark.color = Color.argb((60 + 195 * tw).toInt(), 235, 244, 255)
            canvas.drawCircle(cx + rr * cos(ang), cy + rr * sin(ang), sparkSize[i] * d * (0.6f + 0.6f * tw), spark)
        }
    }
}

/** Boule flottante : apparaît avec une animation, déplaçable, un toucher = JARVIS s'active. */
class OrbOverlay(private val context: Context, private val onTap: () -> Unit) {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = context.getSharedPreferences("jarvis_orb", Context.MODE_PRIVATE)
    private var view: OrbView? = null

    val isShown get() = view != null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (view != null) return
        val size = (96 * context.resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", context.resources.displayMetrics.widthPixels - size - 8)
            y = prefs.getInt("y", context.resources.displayMetrics.heightPixels / 3)
        }
        val v = OrbView(context)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                    v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(90).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) > 14 || abs(e.rawY - downY) > 14) moved = true
                    if (moved) {
                        lp.x = startX + (e.rawX - downX).toInt()
                        lp.y = startY + (e.rawY - downY).toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                    if (e.action == MotionEvent.ACTION_UP) {
                        if (moved) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply() else onTap()
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(v, lp)
            view = v
            // apparition : la boule jaillit en tournant, avec un rebond
            v.scaleX = 0f; v.scaleY = 0f; v.alpha = 0f; v.rotation = -220f
            v.animate().scaleX(1f).scaleY(1f).alpha(1f).rotation(0f)
                .setDuration(700).setInterpolator(OvershootInterpolator(1.8f)).start()
        } catch (e: Exception) { view = null }
    }

    fun setState(s: OrbState) { view?.setOrbState(s) }

    fun hide() {
        val v = view ?: return
        view = null
        v.animate().scaleX(0f).scaleY(0f).alpha(0f).rotation(180f).setDuration(240)
            .withEndAction { try { wm.removeView(v) } catch (e: Exception) {} }.start()
    }
}
