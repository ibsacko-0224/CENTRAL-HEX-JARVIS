package com.centralhex.jarvis

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.centralhex.jarvis.data.LocalStore
import com.centralhex.jarvis.data.Note

/** Reçoit un texte partagé depuis une autre appli (« Partager » ▸ JARVIS) et l'ajoute à tes notes. */
class ShareActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = if (intent?.action == Intent.ACTION_SEND) intent.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty() else ""
        if (text.isNotEmpty()) {
            val store = LocalStore(applicationContext)
            val s = store.load()
            store.save(s.copy(notes = s.notes + Note(text = text.take(500))))
            Toast.makeText(this, "Ajouté aux notes de JARVIS", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
