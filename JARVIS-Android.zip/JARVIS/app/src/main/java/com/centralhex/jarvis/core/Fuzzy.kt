package com.centralhex.jarvis.core

import java.text.Normalizer

/**
 * Comparaison « à l'oreille » : le petit modèle vocal hors ligne écrit les mots anglais à la française
 * (« Facebook » → « face book », « fesse bouc »). On compare donc les SONORITÉS plutôt que l'orthographe.
 */
object Fuzzy {

    fun clean(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ").trim()

    fun distance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    /** Clé phonétique approximative (français + anglais courant). */
    fun phon(s: String): String {
        var t = clean(s).replace(" ", "")
        val rules = listOf(
            "eau" to "o", "wh" to "v", "ph" to "f", "ck" to "k", "qu" to "k", "ch" to "sh", "ou" to "u", "oo" to "u",
            "ai" to "e", "ei" to "e", "au" to "o", "eu" to "e", "oi" to "oa", "ee" to "i",
            "w" to "v", "x" to "ks", "y" to "i", "z" to "s"
        )
        for ((a, b) in rules) t = t.replace(a, b)
        t = t.replace(Regex("c(?=[eiy])"), "s").replace("c", "k").replace(Regex("g(?=[ei])"), "j")
        t = t.replace(Regex("(.)\\1+"), "$1")
        return t
    }

    private fun skeleton(p: String): String =
        if (p.isEmpty()) p else p.first() + p.drop(1).replace(Regex("[aeiou]"), "")

    private fun sim(a: String, b: String): Double {
        val m = maxOf(a.length, b.length)
        return if (m == 0) 0.0 else 1.0 - distance(a, b).toDouble() / m
    }

    /** 0.0 (rien à voir) → 1.0 (même son). */
    fun similarity(a: String, b: String): Double {
        val pa = phon(a)
        val pb = phon(b)
        if (pa.isEmpty() || pb.isEmpty()) return 0.0
        var best = sim(pa, pb)
        val sa = skeleton(pa)
        val sb = skeleton(pb)
        if (sa.length >= 3 && sa == sb) best = maxOf(best, 0.9) else best = maxOf(best, sim(sa, sb) * 0.85)
        if (pa.length >= 4 && pb.startsWith(pa)) best = maxOf(best, 0.85)
        if (pb.length >= 4 && pa.startsWith(pb)) best = maxOf(best, 0.85)
        return best
    }
}
